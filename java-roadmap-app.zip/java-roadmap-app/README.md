# Java Programming Roadmap

A sequential, interactive Java Programming Roadmap web app: strict lesson
locking, a dual assessment framework (Knowledge Test + Practical Coding
Test), and a real `javac`/`java` execution engine behind the code sandbox.

Curriculum source: the attached DepEd "Computer Programming (Java)"
Grade 11/12 PDF, scoped to the brief's mandatory list — Java Setup through
Encapsulation / Inheritance / Polymorphism / Abstraction (12 lessons). The
schema and grading engine are curriculum-agnostic: add more rows to
`backend/src/data/curriculum.js` to extend into Quarter 3's
Exceptions/Collections or Quarter 4's Multithreading/Swing content with no
code changes.

## Stack

- **Frontend:** React 18 + TypeScript + Vite + Tailwind CSS, Monaco editor
- **Backend:** Node.js + Express, JWT auth, `better-sqlite3`
- **Execution engine:** direct `javac`/`java` child processes (dev/reference
  implementation — see hardening notes in
  `backend/src/services/javaExecutionService.js` before exposing this to
  public traffic)

## 1. Local development (no Docker)

### Prerequisites
- Node.js 18+
- A JDK on `PATH` (`javac -version` and `java -version` must both work) —
  JDK 17+ recommended

### Backend

```
cd backend
npm install
cp .env.example .env        # edit JWT_SECRET for anything beyond local dev
npm run seed                # creates data.sqlite and loads the 12 lessons
npm run dev                 # http://localhost:4000
```

### Frontend

```
cd frontend
npm install
npm run dev                 # http://localhost:5173, proxies /api -> :4000
```

Open `http://localhost:5173`, register an account, and Lesson 1 is
unlocked automatically.

## 2. Docker Compose (backend ships its own JDK)

```
JWT_SECRET=$(openssl rand -hex 32) docker compose up --build
```

- Frontend: `http://localhost:8080`
- Backend API: `http://localhost:4000/api/health`

The `backend` container installs `openjdk-17-jdk-headless` alongside Node so
`javac`/`java` are available to `javaExecutionService.js` without any host
setup. Compose applies a memory and process-count cap to that container as a
first line of defense — see "Hardening the execution engine" below before
using this for anything beyond a demo/classroom deployment.

Re-seed inside the running container any time:

```
docker compose exec backend npm run seed
```

## 3. Re-seeding / editing the curriculum

`backend/src/db/seed.js` wipes and reloads `lessons`, `knowledge_questions`,
`coding_challenges`, and `test_cases` from `backend/src/data/curriculum.js`
— it never touches `users` or `user_progress`, so re-seeding to fix a typo
in a lesson does not reset anyone's progress. Edit the array in
`curriculum.js` (same shape for every lesson: `theory`, `knowledgeQuestions`,
`codingChallenge`) and re-run `npm run seed`.

## 4. Hardening the execution engine for production

The shipped `javaExecutionService.js` spawns `javac`/`java` directly on the
API host with a wall-clock timeout and an output-size cap — enough for a
classroom/demo deployment behind auth, not enough for public, anonymous
traffic. Before that:

- Move compilation/execution into its own isolated worker: a locked-down
  Docker container per submission (`--network none`, `--memory`,
  `--pids-limit`, `--cpus`, read-only root filesystem, non-root user), or an
  external judge service (e.g. a self-hosted Judge0 instance) called over
  HTTP from `javaExecutionService.js` instead of `child_process.spawn`.
- Rate-limit `/practical/run` and `/practical/submit` per user.
- Move off SQLite to Postgres for concurrent-write safety at scale — only
  `backend/src/db/connection.js` needs to change; every controller/service
  talks to the small `db.prepare/get/all/run` interface it exports.

## 5. Running tests / adding lessons

- Backend has no test framework wired up yet beyond `node --check` syntax
  validation; `npm test` is a placeholder (`node --test tests/`) — add
  Jest/Vitest specs under `backend/tests/` as the codebase grows.
- To add a 13th lesson (e.g. moving into Quarter 3's Exception Handling),
  append an object to the array in `backend/src/data/curriculum.js` with the
  next `order` value, then re-run `npm run seed`. No controller, route, or
  frontend component needs to change — the whole platform is data-driven off
  this file plus the four lesson-scoped DB tables it seeds.
