// server.js
// ----------------------------------------------------------------------------
// App bootstrap: middleware, routes, DB migration-on-boot, error handling.
// ----------------------------------------------------------------------------
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { migrate } = require('./db/connection');

const authRoutes = require('./routes/authRoutes');
const lessonRoutes = require('./routes/lessonRoutes');
const assessmentRoutes = require('./routes/assessmentRoutes');

migrate(); // safe to call on every boot — CREATE TABLE IF NOT EXISTS

const app = express();
app.use(cors());
app.use(express.json({ limit: '256kb' })); // generous enough for a Java source submission

app.get('/api/health', (req, res) => res.json({ status: 'ok' }));

app.use('/api/auth', authRoutes);
app.use('/api/lessons', lessonRoutes);
app.use('/api/lessons', assessmentRoutes);

// 404 fallback
app.use('/api', (req, res) => res.status(404).json({ error: 'Not found.' }));

// Central error handler
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Internal server error.' });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`Java Roadmap API listening on http://localhost:${PORT}`);
});
