const express = require('express');
const { requireAuth } = require('../middleware/auth');
const { getRoadmap, getLessonDetail } = require('../controllers/lessonController');

const router = express.Router();

router.use(requireAuth);
router.get('/', getRoadmap);
router.get('/:lessonId', getLessonDetail);

module.exports = router;
