const express = require('express');
const { requireAuth } = require('../middleware/auth');
const { requireLessonUnlocked } = require('../middleware/progression');
const { submitKnowledgeTest } = require('../controllers/knowledgeTestController');
const { runCode, submitCode } = require('../controllers/practicalController');

const router = express.Router();

router.use(requireAuth);

// All routes below are scoped to /api/lessons/:lessonId/... and require the
// lesson to be unlocked for the authenticated user (checked server-side,
// independent of whatever the front-end UI currently shows).
router.post('/:lessonId/knowledge-test/submit', requireLessonUnlocked, submitKnowledgeTest);
router.post('/:lessonId/practical/run', requireLessonUnlocked, runCode);
router.post('/:lessonId/practical/submit', requireLessonUnlocked, submitCode);

module.exports = router;
