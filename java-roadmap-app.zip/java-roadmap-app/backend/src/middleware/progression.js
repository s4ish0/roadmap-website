// middleware/progression.js
// ----------------------------------------------------------------------------
// A second, independent enforcement point for the lock rule. gradingService
// is the source of truth for *writing* progress; this middleware is what
// *rejects* an assessment attempt for a lesson the user hasn't unlocked yet
// — defense in depth so a crafted request can't submit for a locked lesson
// even if the front-end's own lock UI is bypassed.
// ----------------------------------------------------------------------------
const { db } = require('../db/connection');
const { ensureInitialized, getOrCreateProgress } = require('../services/gradingService');

function requireLessonUnlocked(req, res, next) {
  const userId = req.user.id;
  const lessonId = Number(req.params.lessonId);

  const lesson = db.prepare('SELECT * FROM lessons WHERE id = ?').get(lessonId);
  if (!lesson) {
    return res.status(404).json({ error: 'Lesson not found.' });
  }

  ensureInitialized(userId);
  const progress = getOrCreateProgress(userId, lessonId);

  if (progress.status === 'locked') {
    return res.status(403).json({
      error: 'This lesson is locked. Pass the previous lesson\'s Knowledge and Practical tests (>= 80%) to unlock it.',
    });
  }

  req.lesson = lesson;
  req.progress = progress;
  next();
}

module.exports = { requireLessonUnlocked };
