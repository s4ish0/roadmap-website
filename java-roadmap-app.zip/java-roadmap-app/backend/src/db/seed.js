// db/seed.js
// ----------------------------------------------------------------------------
// Idempotent seeder: wipes lesson-related tables (never touches users or
// progress) and reloads them from data/curriculum.js. Run with:
//   npm run seed
// ----------------------------------------------------------------------------
const { db, migrate } = require('./connection');
const curriculum = require('../data/curriculum');

function seed() {
  migrate();

  const wipe = db.transaction(() => {
    db.prepare('DELETE FROM test_cases').run();
    db.prepare('DELETE FROM coding_challenges').run();
    db.prepare('DELETE FROM knowledge_questions').run();
    db.prepare('DELETE FROM lessons').run();
  });
  wipe();

  const insertLesson = db.prepare(`
    INSERT INTO lessons
      (order_index, slug, title, summary, theory_markdown, bloom_levels, unlocked_by_default)
    VALUES (@order_index, @slug, @title, @summary, @theory_markdown, @bloom_levels, @unlocked_by_default)
  `);

  const insertQuestion = db.prepare(`
    INSERT INTO knowledge_questions
      (lesson_id, type, bloom_level, prompt, options_json, correct_answer_json, points, order_index)
    VALUES (@lesson_id, @type, @bloom_level, @prompt, @options_json, @correct_answer_json, @points, @order_index)
  `);

  const insertChallenge = db.prepare(`
    INSERT INTO coding_challenges
      (lesson_id, bloom_level, title, prompt_markdown, starter_code, entry_class, order_index)
    VALUES (@lesson_id, @bloom_level, @title, @prompt_markdown, @starter_code, @entry_class, 0)
  `);

  const insertTestCase = db.prepare(`
    INSERT INTO test_cases
      (challenge_id, stdin, expected_stdout, is_hidden, order_index)
    VALUES (@challenge_id, @stdin, @expected_stdout, @is_hidden, @order_index)
  `);

  const loadAll = db.transaction(() => {
    for (const lesson of curriculum) {
      const lessonResult = insertLesson.run({
        order_index: lesson.order,
        slug: lesson.slug,
        title: lesson.title,
        summary: lesson.summary,
        theory_markdown: lesson.theory,
        bloom_levels: JSON.stringify(lesson.bloomLevels),
        unlocked_by_default: lesson.unlockedByDefault ? 1 : 0,
      });
      const lessonId = lessonResult.lastInsertRowid;

      lesson.knowledgeQuestions.forEach((q, idx) => {
        insertQuestion.run({
          lesson_id: lessonId,
          type: q.type,
          bloom_level: q.bloom,
          prompt: q.prompt,
          options_json: q.options ? JSON.stringify(q.options) : null,
          correct_answer_json: JSON.stringify(q.correct),
          points: q.points,
          order_index: idx,
        });
      });

      const cc = lesson.codingChallenge;
      const challengeResult = insertChallenge.run({
        lesson_id: lessonId,
        bloom_level: cc.bloom,
        title: cc.title,
        prompt_markdown: cc.prompt,
        starter_code: cc.starterCode,
        entry_class: cc.entryClass,
      });
      const challengeId = challengeResult.lastInsertRowid;

      cc.testCases.forEach((tc, idx) => {
        insertTestCase.run({
          challenge_id: challengeId,
          stdin: tc.stdin,
          expected_stdout: tc.expected,
          is_hidden: tc.hidden ? 1 : 0,
          order_index: idx,
        });
      });
    }
  });
  loadAll();

  console.log(`Seeded ${curriculum.length} lessons.`);
}

if (require.main === module) {
  seed();
  process.exit(0);
}

module.exports = { seed };
