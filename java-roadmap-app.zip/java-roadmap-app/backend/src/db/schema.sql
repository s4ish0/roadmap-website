-- ============================================================================
-- Java Programming Roadmap — Database Schema
-- Engine target: SQLite (dev, used by db/connection.js) — statements are
-- plain ANSI SQL so this file also runs unmodified on Postgres/MySQL for
-- production by swapping the driver in connection.js.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- USERS
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  username        TEXT NOT NULL UNIQUE,
  email           TEXT NOT NULL UNIQUE,
  password_hash   TEXT NOT NULL,
  display_name    TEXT NOT NULL,
  created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ---------------------------------------------------------------------------
-- LESSONS — the sequential roadmap nodes. order_index defines the strict
-- sequence enforced by the progression engine (lesson N+1 requires N passed).
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS lessons (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  order_index       INTEGER NOT NULL UNIQUE,      -- 1, 2, 3 ... strict order
  slug              TEXT NOT NULL UNIQUE,          -- 'java-setup', 'variables', ...
  title             TEXT NOT NULL,
  summary           TEXT NOT NULL,
  theory_markdown   TEXT NOT NULL,                 -- full lecture content (Markdown)
  bloom_levels      TEXT NOT NULL,                 -- JSON array, e.g. ["Remember","Understand"]
  unlocked_by_default INTEGER NOT NULL DEFAULT 0,  -- 1 only for Lesson 1
  pass_threshold    REAL NOT NULL DEFAULT 0.80,    -- 80% required on BOTH assessments
  created_at        TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ---------------------------------------------------------------------------
-- KNOWLEDGE TEST QUESTIONS — Multiple Choice + Enumeration
-- (Bloom's: Remember, Understand)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS knowledge_questions (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  lesson_id       INTEGER NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
  type            TEXT NOT NULL CHECK (type IN ('mcq', 'enumeration')),
  bloom_level     TEXT NOT NULL,                  -- 'Remember' | 'Understand'
  prompt          TEXT NOT NULL,
  options_json    TEXT,                           -- JSON array, mcq only: ["a","b","c","d"]
  correct_answer_json TEXT NOT NULL,               -- mcq: "b" | enumeration: ["item1","item2",...]
  points          INTEGER NOT NULL DEFAULT 1,
  order_index     INTEGER NOT NULL DEFAULT 0
);

-- ---------------------------------------------------------------------------
-- CODING CHALLENGES — the Practical Coding Test
-- (Bloom's: Apply, Analyze, Create)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS coding_challenges (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  lesson_id       INTEGER NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
  bloom_level     TEXT NOT NULL,                  -- 'Apply' | 'Analyze' | 'Create'
  title           TEXT NOT NULL,
  prompt_markdown TEXT NOT NULL,
  starter_code    TEXT NOT NULL,                  -- boilerplate shown in the editor
  reference_solution TEXT,                        -- instructor-only, used for sanity checks
  entry_class     TEXT NOT NULL DEFAULT 'Main',    -- public class name the runner compiles
  time_limit_ms   INTEGER NOT NULL DEFAULT 5000,
  order_index     INTEGER NOT NULL DEFAULT 0
);

-- ---------------------------------------------------------------------------
-- TEST CASES — stdin -> expected stdout, scored against compiled output.
-- is_hidden = 1 cases are withheld from the learner and only run on submit.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS test_cases (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  challenge_id    INTEGER NOT NULL REFERENCES coding_challenges(id) ON DELETE CASCADE,
  stdin           TEXT NOT NULL DEFAULT '',
  expected_stdout TEXT NOT NULL,
  is_hidden       INTEGER NOT NULL DEFAULT 0,
  weight          INTEGER NOT NULL DEFAULT 1,
  order_index     INTEGER NOT NULL DEFAULT 0
);

-- ---------------------------------------------------------------------------
-- USER PROGRESS — one row per (user, lesson). This is the single source of
-- truth the progression engine reads to decide lock/unlock state.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS user_progress (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id             INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  lesson_id           INTEGER NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
  status              TEXT NOT NULL DEFAULT 'locked'
                        CHECK (status IN ('locked', 'unlocked', 'in_progress', 'completed')),
  knowledge_score     REAL,                       -- 0..1
  practical_score     REAL,                       -- 0..1
  knowledge_passed    INTEGER NOT NULL DEFAULT 0,
  practical_passed    INTEGER NOT NULL DEFAULT 0,
  knowledge_attempts  INTEGER NOT NULL DEFAULT 0,
  practical_attempts  INTEGER NOT NULL DEFAULT 0,
  completed_at        TEXT,
  updated_at          TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (user_id, lesson_id)
);

-- ---------------------------------------------------------------------------
-- SUBMISSIONS — audit trail of every practical run/submit for review & replay
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS submissions (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id         INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  challenge_id    INTEGER NOT NULL REFERENCES coding_challenges(id) ON DELETE CASCADE,
  mode            TEXT NOT NULL CHECK (mode IN ('run', 'submit')),
  source_code     TEXT NOT NULL,
  stdout          TEXT,
  stderr          TEXT,
  passed_cases    INTEGER NOT NULL DEFAULT 0,
  total_cases     INTEGER NOT NULL DEFAULT 0,
  compile_error   INTEGER NOT NULL DEFAULT 0,
  timed_out       INTEGER NOT NULL DEFAULT 0,
  created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ---------------------------------------------------------------------------
-- Helpful indexes
-- ---------------------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_kq_lesson        ON knowledge_questions(lesson_id);
CREATE INDEX IF NOT EXISTS idx_cc_lesson         ON coding_challenges(lesson_id);
CREATE INDEX IF NOT EXISTS idx_tc_challenge      ON test_cases(challenge_id);
CREATE INDEX IF NOT EXISTS idx_progress_user     ON user_progress(user_id);
CREATE INDEX IF NOT EXISTS idx_submissions_user   ON submissions(user_id);
