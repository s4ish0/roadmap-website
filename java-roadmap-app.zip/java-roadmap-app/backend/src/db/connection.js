// db/connection.js
// ----------------------------------------------------------------------------
// Thin wrapper around better-sqlite3. Swapping to Postgres in production only
// means replacing this file's exports (db.prepare/.get/.all/.run) with an
// equivalent `pg` based query layer — nothing above this layer needs to change
// because every controller/service talks to the small interface exported here.
// ----------------------------------------------------------------------------
const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, '../../data.sqlite');
const SCHEMA_PATH = path.join(__dirname, 'schema.sql');

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

function migrate() {
  const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
  db.exec(schema);
}

module.exports = { db, migrate };
