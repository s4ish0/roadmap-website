// services/gradingService.js
// ----------------------------------------------------------------------------
// Owns two responsibilities that must never drift apart: (1) scoring the two
// assessment types, and (2) the strict-sequential unlock rule. Every write to
// user_progress goes through here, so this file is the entire progression
// state engine in one place — no controller mutates progress rows directly.
// ----------------------------------------------------------------------------
const { db } = require('../db/connection');

const PASS_THRESHOLD_DEFAULT = 0.8;

/**
 * Grades a knowledge test submission.
 * @param {Array} questions rows from knowledge_questions for the lesson
 * @param {Object} answers map of questionId -> submitted answer
 *   (mcq: a string matching one option; enumeration: an array of strings)
 */
function gradeKnowledgeAnswers(questions, answers) {
  let earned = 0;
  let possible = 0;
  const breakdown = [];

  for (const q of questions) {
    possible += q.points;
    const correct = JSON.parse(q.correct_answer_json);
    const submitted = answers[q.id];
    let questionScore = 0;

    if (q.type === 'mcq') {
      if (submitted && String(submitted).trim() === String(correct).trim()) {
        questionScore = q.points;
      }
    } else if (q.type === 'enumeration') {
      // Partial credit: award points proportional to correct items submitted,
      // case-insensitive, order-independent, no duplicate double-counting.
      const correctSet = new Set(correct.map((s) => s.trim().toLowerCase()));
      const submittedList = Array.isArray(submitted) ? submitted : [];
      const seen = new Set();
      let matches = 0;
      for (const item of submittedList) {
        const norm = String(item).trim().toLowerCase();
        if (correctSet.has(norm) && !seen.has(norm)) {
          seen.add(norm);
          matches += 1;
        }
      }
      questionScore = correctSet.size > 0 ? (matches / correctSet.size) * q.points : 0;
    }

    earned += questionScore;
    breakdown.push({ questionId: q.id, earned: questionScore, possible: q.points });
  }

  const score = possible > 0 ? earned / possible : 0;
  return { score, earned, possible, breakdown };
}

function getOrCreateProgress(userId, lessonId) {
  let row = db
    .prepare('SELECT * FROM user_progress WHERE user_id = ? AND lesson_id = ?')
    .get(userId, lessonId);

  if (!row) {
    db.prepare(
      `INSERT INTO user_progress (user_id, lesson_id, status) VALUES (?, ?, 'locked')`
    ).run(userId, lessonId);
    row = db.prepare('SELECT * FROM user_progress WHERE user_id = ? AND lesson_id = ?').get(userId, lessonId);
  }
  return row;
}

/**
 * Ensures lesson 1 (unlocked_by_default) is marked unlocked for a user the
 * first time we see them, and that a progress row exists for every lesson.
 */
function ensureInitialized(userId) {
  const lessons = db.prepare('SELECT * FROM lessons ORDER BY order_index ASC').all();
  for (const lesson of lessons) {
    const existing = db
      .prepare('SELECT id FROM user_progress WHERE user_id = ? AND lesson_id = ?')
      .get(userId, lesson.id);
    if (!existing) {
      db.prepare(
        `INSERT INTO user_progress (user_id, lesson_id, status) VALUES (?, ?, ?)`
      ).run(userId, lesson.id, lesson.unlocked_by_default ? 'unlocked' : 'locked');
    }
  }
}

/**
 * Records a knowledge test result and re-evaluates unlock state.
 */
function recordKnowledgeResult(userId, lessonId, score, threshold) {
  const progress = getOrCreateProgress(userId, lessonId);
  const passed = score >= threshold;

  db.prepare(
    `UPDATE user_progress
     SET knowledge_score = ?, knowledge_passed = ?, knowledge_attempts = knowledge_attempts + 1,
         status = CASE WHEN status = 'locked' THEN 'in_progress' ELSE status END,
         updated_at = datetime('now')
     WHERE id = ?`
  ).run(score, passed ? 1 : 0, progress.id);

  return maybeCompleteAndUnlockNext(userId, lessonId, threshold);
}

/**
 * Records a practical test result and re-evaluates unlock state.
 */
function recordPracticalResult(userId, lessonId, score, threshold) {
  const progress = getOrCreateProgress(userId, lessonId);
  const passed = score >= threshold;

  db.prepare(
    `UPDATE user_progress
     SET practical_score = ?, practical_passed = ?, practical_attempts = practical_attempts + 1,
         status = CASE WHEN status = 'locked' THEN 'in_progress' ELSE status END,
         updated_at = datetime('now')
     WHERE id = ?`
  ).run(score, passed ? 1 : 0, progress.id);

  return maybeCompleteAndUnlockNext(userId, lessonId, threshold);
}

/**
 * The core rule: Lesson N+1 unlocks only when Lesson N has
 * knowledge_passed = 1 AND practical_passed = 1 (both >= threshold).
 * Idempotent — safe to call after every grading event.
 */
function maybeCompleteAndUnlockNext(userId, lessonId, threshold = PASS_THRESHOLD_DEFAULT) {
  const progress = db
    .prepare('SELECT * FROM user_progress WHERE user_id = ? AND lesson_id = ?')
    .get(userId, lessonId);

  const bothPassed = !!progress.knowledge_passed && !!progress.practical_passed;

  if (bothPassed && progress.status !== 'completed') {
    db.prepare(
      `UPDATE user_progress SET status = 'completed', completed_at = datetime('now'), updated_at = datetime('now') WHERE id = ?`
    ).run(progress.id);
  }

  let unlockedNext = null;
  if (bothPassed) {
    const currentLesson = db.prepare('SELECT * FROM lessons WHERE id = ?').get(lessonId);
    const nextLesson = db
      .prepare('SELECT * FROM lessons WHERE order_index = ?')
      .get(currentLesson.order_index + 1);

    if (nextLesson) {
      const nextProgress = getOrCreateProgress(userId, nextLesson.id);
      if (nextProgress.status === 'locked') {
        db.prepare(
          `UPDATE user_progress SET status = 'unlocked', updated_at = datetime('now') WHERE id = ?`
        ).run(nextProgress.id);
      }
      unlockedNext = nextLesson;
    }
  }

  return {
    lessonCompleted: bothPassed,
    unlockedNextLesson: unlockedNext,
  };
}

module.exports = {
  gradeKnowledgeAnswers,
  ensureInitialized,
  getOrCreateProgress,
  recordKnowledgeResult,
  recordPracticalResult,
  maybeCompleteAndUnlockNext,
  PASS_THRESHOLD_DEFAULT,
};
