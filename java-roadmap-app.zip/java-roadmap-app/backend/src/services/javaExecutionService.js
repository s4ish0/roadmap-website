// services/javaExecutionService.js
// ----------------------------------------------------------------------------
// Compiles and runs a single learner-submitted Java file against one or more
// stdin/stdout test cases. This module is the boundary between "trusted
// platform code" and "untrusted learner code" — see the hardening notes
// below and in Section 1 of the accompanying write-up for what to add before
// this touches real, unauthenticated traffic in production.
//
// Design (dev/reference implementation):
//   1. Write the submitted source to an isolated temp directory as
//      <entryClass>.java (javac requires the file name to match the public
//      class name).
//   2. Compile once with `javac`. A compile error short-circuits every test
//      case — there is no partial credit for code that doesn't build.
//   3. For each test case, spawn a fresh `java` process, pipe stdin in,
//      capture stdout/stderr, and enforce a wall-clock timeout (kills the
//      process and marks the case as timed out — this is what stops an
//      accidental or deliberate infinite loop from hanging the server).
//   4. Compare trimmed stdout to the trimmed expected output.
//
// PRODUCTION HARDENING (not enabled by default in this reference build):
//   - Run compilation/execution inside a locked-down Docker container
//     (--network none, --memory, --pids-limit, --cpus, read-only rootfs,
//     non-root user) or a Judge0-style isolated worker queue instead of
//     directly on the API host.
//   - Enforce output size caps (truncate/kill a process that floods stdout).
//   - Never reuse a temp directory across submissions; always mkdtemp + rm.
// ----------------------------------------------------------------------------
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

const DEFAULT_TIMEOUT_MS = 5000;
const COMPILE_TIMEOUT_MS = 10000;
const MAX_OUTPUT_BYTES = 200 * 1024; // 200KB guard against runaway stdout

/**
 * Runs a child process, capturing stdout/stderr, enforcing a timeout, and
 * optionally piping stdin.
 */
function runProcess(command, args, { cwd, input = '', timeoutMs }) {
  return new Promise((resolve) => {
    const child = spawn(command, args, { cwd });
    let stdout = '';
    let stderr = '';
    let timedOut = false;
    let settled = false;

    const timer = setTimeout(() => {
      timedOut = true;
      child.kill('SIGKILL');
    }, timeoutMs);

    child.stdout.on('data', (chunk) => {
      if (stdout.length < MAX_OUTPUT_BYTES) stdout += chunk.toString();
    });
    child.stderr.on('data', (chunk) => {
      if (stderr.length < MAX_OUTPUT_BYTES) stderr += chunk.toString();
    });

    child.on('error', (err) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve({ code: -1, stdout, stderr: stderr + '\n' + err.message, timedOut: false });
    });

    child.on('close', (code) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve({ code, stdout, stderr, timedOut });
    });

    child.stdin.on('error', () => {
      /* ignore EPIPE if the program exits before reading all stdin */
    });
    child.stdin.write(input);
    child.stdin.end();
  });
}

/**
 * Compiles `sourceCode` (expected to declare `public class <entryClass>`)
 * in a fresh temp directory.
 * @returns {Promise<{ dir: string, success: boolean, stderr: string }>}
 */
async function compile(sourceCode, entryClass) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'javarun-'));
  const filePath = path.join(dir, `${entryClass}.java`);
  fs.writeFileSync(filePath, sourceCode, 'utf8');

  const result = await runProcess('javac', [filePath], {
    cwd: dir,
    timeoutMs: COMPILE_TIMEOUT_MS,
  });

  return {
    dir,
    success: result.code === 0 && !result.timedOut,
    stderr: result.timedOut ? 'Compilation timed out.' : result.stderr,
  };
}

/**
 * Runs the already-compiled entryClass against one stdin string.
 */
async function runOnce(dir, entryClass, stdin, timeoutMs) {
  const result = await runProcess('java', ['-cp', dir, entryClass], {
    cwd: dir,
    input: stdin,
    timeoutMs,
  });
  return result;
}

function cleanup(dir) {
  fs.rm(dir, { recursive: true, force: true }, () => {});
}

function normalize(text) {
  return String(text).replace(/\r\n/g, '\n').trim();
}

/**
 * Public entry point: compiles once, then runs every test case.
 * @param {string} sourceCode
 * @param {string} entryClass
 * @param {Array<{ id?: number, stdin: string, expected_stdout: string, is_hidden?: boolean }>} testCases
 * @param {number} timeLimitMs per-test-case wall clock limit
 * @returns {Promise<{
 *   compileError: boolean, compileStderr: string,
 *   results: Array<{ testCaseId?: number, passed: boolean, stdout: string, stderr: string, timedOut: boolean, hidden: boolean }>,
 *   passedCount: number, totalCount: number
 * }>}
 */
async function runTestCases(sourceCode, entryClass, testCases, timeLimitMs = DEFAULT_TIMEOUT_MS) {
  const { dir, success, stderr } = await compile(sourceCode, entryClass);

  if (!success) {
    cleanup(dir);
    return {
      compileError: true,
      compileStderr: stderr,
      results: [],
      passedCount: 0,
      totalCount: testCases.length,
    };
  }

  const results = [];
  for (const tc of testCases) {
    const run = await runOnce(dir, entryClass, tc.stdin || '', timeLimitMs);
    const passed = !run.timedOut && run.code === 0 && normalize(run.stdout) === normalize(tc.expected_stdout);
    results.push({
      testCaseId: tc.id,
      passed,
      stdout: run.stdout,
      stderr: run.stderr,
      timedOut: run.timedOut,
      hidden: !!tc.is_hidden,
    });
  }

  cleanup(dir);

  return {
    compileError: false,
    compileStderr: '',
    results,
    passedCount: results.filter((r) => r.passed).length,
    totalCount: testCases.length,
  };
}

module.exports = { runTestCases, compile, runOnce, cleanup };
