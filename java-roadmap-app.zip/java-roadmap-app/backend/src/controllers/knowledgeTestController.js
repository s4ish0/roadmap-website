// controllers/knowledgeTestController.js
const { db } = require('../db/connection');
const { gradeKnowledgeAnswers, recordKnowledgeResult } = require('../services/gradingService');

/**
 * POST /api/lessons/:lessonId/knowledge-test/submit
 * body: { answers: { [questionId]: string | string[] } }
 */
function submitKnowledgeTest(req, res) {
  const userId = req.user.id;
  const lesson = req.lesson; // set by requireLessonUnlocked
  const answers = (req.body && req.body.answers) || {};

  const questions = db
    .prepare('SELECT * FROM knowledge_questions WHERE lesson_id = ?')
    .all(lesson.id);

  if (questions.length === 0) {
    return res.status(400).json({ error: 'This lesson has no knowledge test questions.' });
  }

  const { score, earned, possible, breakdown } = gradeKnowledgeAnswers(questions, answers);
  const { lessonCompleted, unlockedNextLesson } = recordKnowledgeResult(
    userId,
    lesson.id,
    score,
    lesson.pass_threshold
  );

  res.json({
    score,
    earnedPoints: earned,
    possiblePoints: possible,
    passed: score >= lesson.pass_threshold,
    threshold: lesson.pass_threshold,
    breakdown,
    lessonCompleted,
    unlockedNextLesson: unlockedNextLesson
      ? { id: unlockedNextLesson.id, slug: unlockedNextLesson.slug, title: unlockedNextLesson.title }
      : null,
  });
}

module.exports = { submitKnowledgeTest };
