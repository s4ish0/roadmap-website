// controllers/practicalController.js
const { db } = require('../db/connection');
const { runTestCases } = require('../services/javaExecutionService');
const { recordPracticalResult } = require('../services/gradingService');

function loadChallenge(lessonId) {
  return db
    .prepare('SELECT * FROM coding_challenges WHERE lesson_id = ? ORDER BY order_index ASC LIMIT 1')
    .get(lessonId);
}

/**
 * POST /api/lessons/:lessonId/practical/run
 * body: { code: string }
 * Compiles + runs against VISIBLE test cases only. Does NOT grade or affect
 * progression — this is the "Run" button in the sandbox, for iterating.
 */
async function runCode(req, res) {
  const lesson = req.lesson;
  const { code } = req.body || {};
  if (!code || typeof code !== 'string') {
    return res.status(400).json({ error: 'code (string) is required.' });
  }

  const challenge = loadChallenge(lesson.id);
  if (!challenge) return res.status(404).json({ error: 'No coding challenge for this lesson.' });

  const visibleCases = db
    .prepare('SELECT * FROM test_cases WHERE challenge_id = ? AND is_hidden = 0 ORDER BY order_index ASC')
    .all(challenge.id);

  const outcome = await runTestCases(code, challenge.entry_class, visibleCases, challenge.time_limit_ms);

  db.prepare(
    `INSERT INTO submissions (user_id, challenge_id, mode, source_code, stdout, stderr, passed_cases, total_cases, compile_error, timed_out)
     VALUES (?, ?, 'run', ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    req.user.id,
    challenge.id,
    code,
    outcome.results.map((r) => r.stdout).join('\n---\n'),
    outcome.compileError ? outcome.compileStderr : outcome.results.map((r) => r.stderr).join('\n---\n'),
    outcome.passedCount,
    outcome.totalCount,
    outcome.compileError ? 1 : 0,
    outcome.results.some((r) => r.timedOut) ? 1 : 0
  );

  res.json({
    compileError: outcome.compileError,
    compileStderr: outcome.compileStderr,
    results: outcome.results.map((r) => ({
      testCaseId: r.testCaseId,
      passed: r.passed,
      stdout: r.stdout,
      stderr: r.stderr,
      timedOut: r.timedOut,
    })),
    passedCount: outcome.passedCount,
    totalCount: outcome.totalCount,
  });
}

/**
 * POST /api/lessons/:lessonId/practical/submit
 * body: { code: string }
 * Compiles + runs against ALL test cases (visible + hidden), grades, and
 * updates progression. This is the "Submit" action in the wireframe.
 */
async function submitCode(req, res) {
  const lesson = req.lesson;
  const { code } = req.body || {};
  if (!code || typeof code !== 'string') {
    return res.status(400).json({ error: 'code (string) is required.' });
  }

  const challenge = loadChallenge(lesson.id);
  if (!challenge) return res.status(404).json({ error: 'No coding challenge for this lesson.' });

  const allCases = db
    .prepare('SELECT * FROM test_cases WHERE challenge_id = ? ORDER BY order_index ASC')
    .all(challenge.id);

  const outcome = await runTestCases(code, challenge.entry_class, allCases, challenge.time_limit_ms);
  const score = outcome.totalCount > 0 ? outcome.passedCount / outcome.totalCount : 0;

  db.prepare(
    `INSERT INTO submissions (user_id, challenge_id, mode, source_code, stdout, stderr, passed_cases, total_cases, compile_error, timed_out)
     VALUES (?, ?, 'submit', ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    req.user.id,
    challenge.id,
    code,
    outcome.results.map((r) => r.stdout).join('\n---\n'),
    outcome.compileError ? outcome.compileStderr : outcome.results.map((r) => r.stderr).join('\n---\n'),
    outcome.passedCount,
    outcome.totalCount,
    outcome.compileError ? 1 : 0,
    outcome.results.some((r) => r.timedOut) ? 1 : 0
  );

  const { lessonCompleted, unlockedNextLesson } = recordPracticalResult(
    req.user.id,
    lesson.id,
    score,
    lesson.pass_threshold
  );

  // Hidden test case bodies are withheld in the response — only pass/fail.
  res.json({
    compileError: outcome.compileError,
    compileStderr: outcome.compileStderr,
    results: outcome.results.map((r) => ({
      testCaseId: r.testCaseId,
      passed: r.passed,
      hidden: r.hidden,
      stdout: r.hidden ? undefined : r.stdout,
      stderr: r.hidden ? undefined : r.stderr,
      timedOut: r.timedOut,
    })),
    passedCount: outcome.passedCount,
    totalCount: outcome.totalCount,
    score,
    passed: score >= lesson.pass_threshold,
    threshold: lesson.pass_threshold,
    lessonCompleted,
    unlockedNextLesson: unlockedNextLesson
      ? { id: unlockedNextLesson.id, slug: unlockedNextLesson.slug, title: unlockedNextLesson.title }
      : null,
  });
}

module.exports = { runCode, submitCode };
