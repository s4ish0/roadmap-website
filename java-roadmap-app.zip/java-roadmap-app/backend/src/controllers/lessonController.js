// controllers/lessonController.js
const { db } = require('../db/connection');
const { ensureInitialized } = require('../services/gradingService');

/**
 * GET /api/lessons
 * Returns every roadmap node plus this user's status for it — exactly what
 * the sidebar / roadmap nodes in the wireframe need to render locked vs.
 * unlocked vs. completed badges without a second round trip.
 */
function getRoadmap(req, res) {
  const userId = req.user.id;
  ensureInitialized(userId);

  const rows = db
    .prepare(
      `SELECT l.id, l.order_index, l.slug, l.title, l.summary, l.bloom_levels,
              p.status, p.knowledge_score, p.practical_score,
              p.knowledge_passed, p.practical_passed
       FROM lessons l
       JOIN user_progress p ON p.lesson_id = l.id AND p.user_id = ?
       ORDER BY l.order_index ASC`
    )
    .all(userId);

  const roadmap = rows.map((r) => ({
    id: r.id,
    order: r.order_index,
    slug: r.slug,
    title: r.title,
    summary: r.summary,
    bloomLevels: JSON.parse(r.bloom_levels),
    status: r.status, // 'locked' | 'unlocked' | 'in_progress' | 'completed'
    knowledgeScore: r.knowledge_score,
    practicalScore: r.practical_score,
    knowledgePassed: !!r.knowledge_passed,
    practicalPassed: !!r.practical_passed,
  }));

  const completedCount = roadmap.filter((r) => r.status === 'completed').length;

  res.json({
    lessons: roadmap,
    overallProgress: roadmap.length ? completedCount / roadmap.length : 0,
  });
}

/**
 * GET /api/lessons/:lessonId
 * Full lesson payload for the Theory Reader + Code Sandbox. Locked lessons
 * return 403 (enforced by requireLessonUnlocked upstream of this handler for
 * lesson-scoped routes; for this read-only route we allow locked lessons to
 * return a minimal locked preview so the UI can render a "locked" state with
 * the title/summary without exposing content).
 */
function getLessonDetail(req, res) {
  const userId = req.user.id;
  const lessonId = Number(req.params.lessonId);
  ensureInitialized(userId);

  const lesson = db.prepare('SELECT * FROM lessons WHERE id = ?').get(lessonId);
  if (!lesson) return res.status(404).json({ error: 'Lesson not found.' });

  const progress = db
    .prepare('SELECT * FROM user_progress WHERE user_id = ? AND lesson_id = ?')
    .get(userId, lessonId);

  if (progress.status === 'locked') {
    return res.json({
      id: lesson.id,
      slug: lesson.slug,
      title: lesson.title,
      summary: lesson.summary,
      status: 'locked',
    });
  }

  const knowledgeQuestions = db
    .prepare('SELECT * FROM knowledge_questions WHERE lesson_id = ? ORDER BY order_index ASC')
    .all(lessonId)
    .map((q) => ({
      id: q.id,
      type: q.type,
      bloomLevel: q.bloom_level,
      prompt: q.prompt,
      options: q.options_json ? JSON.parse(q.options_json) : null,
      points: q.points,
      // correct_answer_json intentionally omitted — graded server-side only
    }));

  const challenge = db
    .prepare('SELECT * FROM coding_challenges WHERE lesson_id = ? ORDER BY order_index ASC LIMIT 1')
    .get(lessonId);

  let codingChallenge = null;
  if (challenge) {
    const visibleTestCases = db
      .prepare('SELECT id, stdin, expected_stdout FROM test_cases WHERE challenge_id = ? AND is_hidden = 0 ORDER BY order_index ASC')
      .all(challenge.id);
    const hiddenCount = db
      .prepare('SELECT COUNT(*) AS c FROM test_cases WHERE challenge_id = ? AND is_hidden = 1')
      .get(challenge.id).c;

    codingChallenge = {
      id: challenge.id,
      bloomLevel: challenge.bloom_level,
      title: challenge.title,
      promptMarkdown: challenge.prompt_markdown,
      starterCode: challenge.starter_code,
      entryClass: challenge.entry_class,
      visibleTestCases,
      hiddenTestCaseCount: hiddenCount,
    };
  }

  res.json({
    id: lesson.id,
    slug: lesson.slug,
    title: lesson.title,
    summary: lesson.summary,
    theoryMarkdown: lesson.theory_markdown,
    bloomLevels: JSON.parse(lesson.bloom_levels),
    status: progress.status,
    passThreshold: lesson.pass_threshold,
    progress: {
      knowledgeScore: progress.knowledge_score,
      practicalScore: progress.practical_score,
      knowledgePassed: !!progress.knowledge_passed,
      practicalPassed: !!progress.practical_passed,
    },
    knowledgeQuestions,
    codingChallenge,
  });
}

module.exports = { getRoadmap, getLessonDetail };
