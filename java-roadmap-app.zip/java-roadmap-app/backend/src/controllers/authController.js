// controllers/authController.js
const bcrypt = require('bcryptjs');
const { db } = require('../db/connection');
const { signToken } = require('../middleware/auth');
const { ensureInitialized } = require('../services/gradingService');

const SALT_ROUNDS = 10;

async function register(req, res) {
  const { username, email, password, displayName } = req.body || {};

  if (!username || !email || !password) {
    return res.status(400).json({ error: 'username, email, and password are required.' });
  }
  if (password.length < 8) {
    return res.status(400).json({ error: 'Password must be at least 8 characters.' });
  }

  const existing = db
    .prepare('SELECT id FROM users WHERE username = ? OR email = ?')
    .get(username, email);
  if (existing) {
    return res.status(409).json({ error: 'Username or email already in use.' });
  }

  const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);
  const result = db
    .prepare('INSERT INTO users (username, email, password_hash, display_name) VALUES (?, ?, ?, ?)')
    .run(username, email, passwordHash, displayName || username);

  const user = { id: result.lastInsertRowid, username };
  ensureInitialized(user.id); // seeds locked/unlocked progress rows for every lesson

  const token = signToken(user);
  return res.status(201).json({ token, user: { id: user.id, username, displayName: displayName || username } });
}

async function login(req, res) {
  const { username, password } = req.body || {};
  if (!username || !password) {
    return res.status(400).json({ error: 'username and password are required.' });
  }

  const row = db.prepare('SELECT * FROM users WHERE username = ? OR email = ?').get(username, username);
  if (!row) {
    return res.status(401).json({ error: 'Invalid credentials.' });
  }

  const valid = await bcrypt.compare(password, row.password_hash);
  if (!valid) {
    return res.status(401).json({ error: 'Invalid credentials.' });
  }

  ensureInitialized(row.id);
  const token = signToken({ id: row.id, username: row.username });
  return res.json({ token, user: { id: row.id, username: row.username, displayName: row.display_name } });
}

module.exports = { register, login };
