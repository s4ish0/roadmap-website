// data/curriculum.js
// ----------------------------------------------------------------------------
// Seed content for the roadmap. Scope note: the brief's mandatory lesson list
// is "Java Setup, Variables, Data Types, Operators, Control Flow, Loops,
// Arrays, Methods, Encapsulation, Inheritance, Polymorphism, Abstraction" —
// this is Quarter 1-3 of the attached DepEd curriculum (fundamentals through
// core OOP). Quarter 3's Exceptions/Collections and Quarter 4's Multithreading
// /Swing GUI content are NOT in the mandatory list, so they are left out of
// seed data but the schema/engine below is content-agnostic: add more rows to
// this array (or a DB admin UI) to extend the roadmap with zero code changes.
// ----------------------------------------------------------------------------

module.exports = [
  {
    order: 1,
    slug: 'java-setup',
    title: 'Java Setup & Program Structure',
    summary: 'Install the JDK, understand the JVM, and write your first compiling, running Java program.',
    bloomLevels: ['Remember', 'Understand'],
    unlockedByDefault: true,
    theory: `## Why Java?

Java was created by James Gosling and his team at Sun Microsystems in the
early 1990s, originally under the name "Oak". Its defining promise is
platform independence: source code compiles to bytecode, and any machine
running a Java Virtual Machine (JVM) can execute that bytecode, regardless
of the underlying operating system — "write once, run anywhere".

## The toolchain

Three pieces make up a working Java setup:

    JDK  (Java Development Kit)   -> compiler (javac), tools, JVM
    IDE  (IntelliJ, Eclipse, VS Code + JDT) -> editor, debugger, project mgmt
    JDT  (Java Development Tools) -> the Java tooling plugged into your IDE

You write source code in a .java file, compile it with javac into a .class
file (bytecode), then run it with the java launcher, which hands the
bytecode to the JVM for execution.

## Anatomy of a program

Every runnable Java program needs a public class whose name matches the
file name, and inside it a main method — the entry point the JVM looks for
first:

    public class Main {
        public static void main(String[] args) {
            System.out.println("Hello, Java!");
        }
    }

Reading this line by line: "public class Main" declares a class named
Main that anything outside the file can see. "public static void main"
is the fixed signature the JVM calls automatically — public so the JVM
can reach it, static so it runs without creating an object first, void
because it returns nothing. "String[] args" holds any command-line
arguments. System.out.println writes a line of text to standard output.

## Comments

Single-line comments start with //, multi-line comments are wrapped in
/* ... */, and /** ... */ starts a Javadoc comment used to generate API
documentation.`,
    knowledgeQuestions: [
      {
        type: 'mcq',
        bloom: 'Remember',
        prompt: 'Who is credited as the lead creator of the Java language at Sun Microsystems?',
        options: ['James Gosling', 'Dennis Ritchie', 'Guido van Rossum', 'Bjarne Stroustrup'],
        correct: 'James Gosling',
        points: 1,
      },
      {
        type: 'mcq',
        bloom: 'Understand',
        prompt: 'What does the JVM actually execute?',
        options: [
          'The raw .java source file',
          'Compiled bytecode (.class file)',
          'Machine code compiled directly for the host CPU',
          'A JSON description of the program',
        ],
        correct: 'Compiled bytecode (.class file)',
        points: 1,
      },
      {
        type: 'mcq',
        bloom: 'Understand',
        prompt: 'Why must the main method be declared static?',
        options: [
          'So it runs before any object of the class is created',
          'So it can only be called once per program',
          'So it can access private fields of other classes',
          'Static has no real effect on main',
        ],
        correct: 'So it runs before any object of the class is created',
        points: 1,
      },
      {
        type: 'enumeration',
        bloom: 'Remember',
        prompt: 'Name the three tools/acronyms that make up a working Java development setup (JDK, IDE, and one more).',
        correct: ['JDK', 'IDE', 'JDT'],
        points: 3,
      },
    ],
    codingChallenge: {
      bloom: 'Apply',
      title: 'Print a Greeting',
      prompt: `Write a program that reads a single line containing a name from standard
input and prints "Hello, <name>!" to standard output (no quotes).

Example
Input:  Ada
Output: Hello, Ada!`,
      starterCode: `import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String name = scanner.nextLine();
        // TODO: print "Hello, <name>!"
    }
}
`,
      entryClass: 'Main',
      testCases: [
        { stdin: 'Ada\n', expected: 'Hello, Ada!', hidden: false },
        { stdin: 'Grace\n', expected: 'Hello, Grace!', hidden: false },
        { stdin: 'Jovi\n', expected: 'Hello, Jovi!', hidden: true },
      ],
    },
  },

  {
    order: 2,
    slug: 'variables-data-types',
    title: 'Variables & Data Types',
    summary: 'Declare variables and choose the right primitive type for the data you are modeling.',
    bloomLevels: ['Remember', 'Understand', 'Apply'],
    unlockedByDefault: false,
    theory: `## Declaring variables

A variable is a named, typed storage location. Java is statically typed:
you declare the type up front, and it cannot change:

    int age = 17;
    double gpa = 1.75;
    boolean isEnrolled = true;
    char grade = 'A';
    String section = "STEM-A";

## The eight primitive types

    byte, short, int, long     -> whole numbers, increasing range
    float, double              -> decimal numbers (double is the default)
    char                       -> a single UTF-16 character
    boolean                    -> true or false only

String is not a primitive — it is a full class from java.lang, but Java
gives it special literal syntax ("like this") so it behaves like one in
everyday code.

## Naming rules

Identifiers must start with a letter, underscore, or dollar sign, may not
be a reserved keyword (class, int, if, ...), and are case-sensitive. Java
convention is camelCase for variables (studentAge), and this convention is
what most style guides and graders expect.

## Type ranges matter

Choosing int for a loop counter and double for money-like values with
fractions is a habit worth building early — using the wrong type is a
common source of subtle bugs, like integer division truncating a
result you expected to be a fraction.`,
    knowledgeQuestions: [
      {
        type: 'mcq',
        bloom: 'Remember',
        prompt: 'Which of these is NOT one of Java\'s eight primitive types?',
        options: ['String', 'boolean', 'char', 'long'],
        correct: 'String',
        points: 1,
      },
      {
        type: 'mcq',
        bloom: 'Understand',
        prompt: 'What value does "int result = 7 / 2;" store?',
        options: ['3', '3.5', '4', 'A compile error'],
        correct: '3',
        points: 1,
      },
      {
        type: 'mcq',
        bloom: 'Remember',
        prompt: 'Which declaration is valid Java?',
        options: ['boolean isEnrolled = true;', 'boolean isEnrolled = "true";', 'bool isEnrolled = true;', 'boolean isEnrolled = 1;'],
        correct: 'boolean isEnrolled = true;',
        points: 1,
      },
      {
        type: 'enumeration',
        bloom: 'Remember',
        prompt: 'List the four integer primitive types in Java, from smallest to largest range.',
        correct: ['byte', 'short', 'int', 'long'],
        points: 4,
      },
    ],
    codingChallenge: {
      bloom: 'Apply',
      title: 'Average of Three Grades',
      prompt: `Read three integers on one line, separated by spaces, representing three
quiz scores. Compute their average as a double and print it with exactly
two decimal places using System.out.printf("%.2f%n", average).

Example
Input:  90 85 92
Output: 89.00`,
      starterCode: `import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int a = scanner.nextInt();
        int b = scanner.nextInt();
        int c = scanner.nextInt();
        // TODO: compute the average as a double and print with 2 decimals
    }
}
`,
      entryClass: 'Main',
      testCases: [
        { stdin: '90 85 92\n', expected: '89.00', hidden: false },
        { stdin: '100 100 100\n', expected: '100.00', hidden: false },
        { stdin: '70 71 72\n', expected: '71.00', hidden: true },
      ],
    },
  },

  {
    order: 3,
    slug: 'operators',
    title: 'Java Operators',
    summary: 'Combine arithmetic, relational, logical, assignment, and increment/decrement operators.',
    bloomLevels: ['Remember', 'Understand', 'Apply'],
    unlockedByDefault: false,
    theory: `## Arithmetic operators

    +   -   *   /   %

% is the modulo (remainder) operator — indispensable for checking
even/odd numbers or wrapping values around a range.

## Relational and logical operators

Relational operators compare two values and produce a boolean:

    ==  !=  >  <  >=  <=

Logical operators combine booleans:

    &&  (AND, short-circuits)
    ||  (OR, short-circuits)
    !   (NOT)

Short-circuiting means the right side of && is skipped entirely if the
left side is already false (and the right side of || is skipped if the
left side is already true) — this is both a performance habit and a way
to safely guard against errors, e.g. (arr != null && arr.length > 0).

## Assignment and compound assignment

    =   +=   -=   *=   /=   %=

score += 5; is shorthand for score = score + 5;

## Increment / decrement

    x++   (post-increment: use, then increment)
    ++x   (pre-increment: increment, then use)

The difference only matters when the operator is used inside a larger
expression, e.g. array[i++] vs array[++i].`,
    knowledgeQuestions: [
      {
        type: 'mcq',
        bloom: 'Understand',
        prompt: 'What does 17 % 5 evaluate to?',
        options: ['2', '3', '3.4', '12'],
        correct: '2',
        points: 1,
      },
      {
        type: 'mcq',
        bloom: 'Understand',
        prompt: 'Given int x = 5; int y = x++;, what is y after this line?',
        options: ['5', '6', '4', 'Undefined'],
        correct: '5',
        points: 1,
      },
      {
        type: 'mcq',
        bloom: 'Remember',
        prompt: 'Which operator short-circuits, skipping its right operand when the left operand already determines the result?',
        options: ['&&', '&', '|', '^'],
        correct: '&&',
        points: 1,
      },
      {
        type: 'enumeration',
        bloom: 'Remember',
        prompt: 'List the three logical operators in Java.',
        correct: ['&&', '||', '!'],
        points: 3,
      },
    ],
    codingChallenge: {
      bloom: 'Apply',
      title: 'Even or Odd, and Sum',
      prompt: `Read a single integer n. Print "EVEN" if it is even or "ODD" if it is odd
on the first line, then print the sum of its digits on the second line
(n will be non-negative).

Example
Input:  482
Output:
EVEN
14`,
      starterCode: `import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        // TODO: print EVEN/ODD, then the digit sum on the next line
    }
}
`,
      entryClass: 'Main',
      testCases: [
        { stdin: '482\n', expected: 'EVEN\n14', hidden: false },
        { stdin: '13\n', expected: 'ODD\n4', hidden: false },
        { stdin: '0\n', expected: 'EVEN\n0', hidden: true },
      ],
    },
  },

  {
    order: 4,
    slug: 'control-flow-conditionals',
    title: 'Control Flow: If/Else & Switch',
    summary: 'Branch program execution with if, if-else, else-if chains, and switch-case.',
    bloomLevels: ['Understand', 'Apply', 'Analyze'],
    unlockedByDefault: false,
    theory: `## if / else if / else

    if (score >= 90) {
        grade = "A";
    } else if (score >= 80) {
        grade = "B";
    } else {
        grade = "C";
    }

Conditions are evaluated top to bottom; the first true branch runs and the
rest are skipped — order matters when ranges overlap.

## switch

switch compares one value against several constant cases. Each case
without a break "falls through" into the next one, which is sometimes
intentional (grouping cases) and sometimes a bug:

    switch (day) {
        case 1:
        case 7:
            type = "Weekend";
            break;
        default:
            type = "Weekday";
    }

Modern Java also supports arrow-style switch expressions
(case 1, 7 -> "Weekend";) which don't fall through by default, but the
classic colon-and-break form above is what you'll see in most existing
code and is what this course tests.

## Nesting and readability

Conditions can nest, but deeply nested if-chains are a common source of
bugs and are usually better expressed as an else-if ladder or a switch
once you're comparing one variable against many discrete values.`,
    knowledgeQuestions: [
      {
        type: 'mcq',
        bloom: 'Understand',
        prompt: 'In an if / else-if / else chain, how many branches can execute for a single pass?',
        options: ['Exactly one', 'Zero or more, whichever match', 'Always all of them', 'Only the last matching one'],
        correct: 'Exactly one',
        points: 1,
      },
      {
        type: 'mcq',
        bloom: 'Analyze',
        prompt: 'A switch case is missing its break statement. What happens?',
        options: [
          'Execution falls through into the next case',
          'A compile error is raised',
          'The switch silently exits',
          'Only the default case runs',
        ],
        correct: 'Execution falls through into the next case',
        points: 1,
      },
      {
        type: 'mcq',
        bloom: 'Apply',
        prompt: 'Which condition correctly checks that a score is in the inclusive range 80 to 89?',
        options: ['score >= 80 && score <= 89', 'score >= 80 || score <= 89', 'score > 80 && score < 89', 'score = 80'],
        correct: 'score >= 80 && score <= 89',
        points: 1,
      },
      {
        type: 'enumeration',
        bloom: 'Remember',
        prompt: 'Name the two Java statements used to branch execution covered in this lesson.',
        correct: ['if-else', 'switch'],
        points: 2,
      },
    ],
    codingChallenge: {
      bloom: 'Apply',
      title: 'Letter Grade Classifier',
      prompt: `Read an integer score (0-100) and print its letter grade using this
scale: 90+ -> A, 80-89 -> B, 70-79 -> C, 60-69 -> D, below 60 -> F.

Example
Input:  84
Output: B`,
      starterCode: `import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int score = scanner.nextInt();
        // TODO: print the letter grade
    }
}
`,
      entryClass: 'Main',
      testCases: [
        { stdin: '84\n', expected: 'B', hidden: false },
        { stdin: '55\n', expected: 'F', hidden: false },
        { stdin: '90\n', expected: 'A', hidden: true },
      ],
    },
  },

  {
    order: 5,
    slug: 'loops',
    title: 'Loops: For, While, Do-While',
    summary: 'Repeat work with for, while, and do-while loops, including nesting and break/continue.',
    bloomLevels: ['Understand', 'Apply', 'Analyze'],
    unlockedByDefault: false,
    theory: `## for loop

Best when the number of iterations is known ahead of time:

    for (int i = 0; i < 5; i++) {
        System.out.println(i);
    }

The three clauses are: initialization (runs once), condition (checked
before every iteration), and update (runs after every iteration body).

## while loop

Best when the loop should continue based on a condition whose iteration
count isn't known in advance:

    int n = 10;
    while (n > 0) {
        n /= 2;
    }

## do-while loop

Guarantees the body runs at least once, because the condition is checked
after the body — this is the natural fit for "run once, then repeat while
valid", such as re-prompting a user after a first attempt:

    int input;
    do {
        input = scanner.nextInt();
    } while (input < 0);

## Nested loops and loop control

Loops can nest (a loop inside a loop) to walk 2D structures like grids.
break exits the nearest enclosing loop immediately; continue skips to the
next iteration without exiting. return exits the entire method, not just
the loop.`,
    knowledgeQuestions: [
      {
        type: 'mcq',
        bloom: 'Understand',
        prompt: 'Which loop type is guaranteed to execute its body at least once?',
        options: ['do-while', 'for', 'while', 'None of them'],
        correct: 'do-while',
        points: 1,
      },
      {
        type: 'mcq',
        bloom: 'Analyze',
        prompt: 'What does "continue" do inside a for loop?',
        options: [
          'Skips the rest of the current iteration and proceeds to the update/condition check',
          'Immediately exits the loop entirely',
          'Exits the enclosing method',
          'Restarts the loop from i = 0',
        ],
        correct: 'Skips the rest of the current iteration and proceeds to the update/condition check',
        points: 1,
      },
      {
        type: 'mcq',
        bloom: 'Apply',
        prompt: 'How many times does "for (int i = 0; i < 4; i++)" execute its body?',
        options: ['4', '3', '5', 'Infinite'],
        correct: '4',
        points: 1,
      },
      {
        type: 'enumeration',
        bloom: 'Remember',
        prompt: 'Name the two keywords used to control loop iteration flow discussed in this lesson (skip one iteration vs. exit the loop entirely).',
        correct: ['continue', 'break'],
        points: 2,
      },
    ],
    codingChallenge: {
      bloom: 'Apply',
      title: 'FizzBuzz',
      prompt: `Read an integer n. For every integer i from 1 to n inclusive, print
"Fizz" if i is divisible by 3, "Buzz" if divisible by 5, "FizzBuzz" if
divisible by both, otherwise print i. One value per line.

Example
Input:  5
Output:
1
2
Fizz
4
Buzz`,
      starterCode: `import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        // TODO: loop from 1 to n and print Fizz/Buzz/FizzBuzz/number
    }
}
`,
      entryClass: 'Main',
      testCases: [
        { stdin: '5\n', expected: '1\n2\nFizz\n4\nBuzz', hidden: false },
        { stdin: '15\n', expected: '1\n2\nFizz\n4\nBuzz\nFizz\n7\n8\nFizz\nBuzz\n11\nFizz\n13\n14\nFizzBuzz', hidden: false },
        { stdin: '1\n', expected: '1', hidden: true },
      ],
    },
  },

  {
    order: 6,
    slug: 'arrays',
    title: 'Arrays',
    summary: 'Store and traverse fixed-size collections with single and multi-dimensional arrays.',
    bloomLevels: ['Understand', 'Apply', 'Analyze'],
    unlockedByDefault: false,
    theory: `## Single-dimensional arrays

An array is a fixed-size, indexed, same-type collection:

    int[] scores = {90, 85, 92, 78};
    int first = scores[0];
    int length = scores.length;   // not a method call, it's a field

Indexes start at 0; accessing scores[scores.length] throws an
ArrayIndexOutOfBoundsException — an off-by-one error that is one of the
most common bugs beginners hit.

## Traversing arrays

    for (int i = 0; i < scores.length; i++) {
        System.out.println(scores[i]);
    }

    for (int score : scores) {   // enhanced for-loop
        System.out.println(score);
    }

The enhanced for-loop is cleaner for read-only traversal, but the classic
indexed loop is still needed whenever you need the index itself, e.g. to
compare neighbours or modify elements in place.

## Two-dimensional arrays

A 2D array is an array of arrays — think of it as rows and columns:

    int[][] grid = new int[3][4];   // 3 rows, 4 columns
    grid[1][2] = 7;

    for (int r = 0; r < grid.length; r++) {
        for (int c = 0; c < grid[r].length; c++) {
            System.out.print(grid[r][c] + " ");
        }
    }`,
    knowledgeQuestions: [
      {
        type: 'mcq',
        bloom: 'Remember',
        prompt: 'What is the index of the first element in a Java array?',
        options: ['0', '1', '-1', 'Depends on the type'],
        correct: '0',
        points: 1,
      },
      {
        type: 'mcq',
        bloom: 'Understand',
        prompt: 'What happens when you access an index equal to or greater than array.length?',
        options: [
          'ArrayIndexOutOfBoundsException at runtime',
          'It silently returns 0 or null',
          'A compile-time error',
          'The array automatically grows',
        ],
        correct: 'ArrayIndexOutOfBoundsException at runtime',
        points: 1,
      },
      {
        type: 'mcq',
        bloom: 'Analyze',
        prompt: 'For a 2D array declared as int[][] grid = new int[3][4], what does grid.length return?',
        options: ['3 (the number of rows)', '4 (the number of columns)', '12 (total elements)', '7'],
        correct: '3 (the number of rows)',
        points: 1,
      },
      {
        type: 'enumeration',
        bloom: 'Remember',
        prompt: 'Name the two loop styles shown in this lesson for traversing an array.',
        correct: ['classic indexed for-loop', 'enhanced for-loop'],
        points: 2,
      },
    ],
    codingChallenge: {
      bloom: 'Analyze',
      title: 'Find the Maximum',
      prompt: `Read an integer n, then n integers on the next line separated by spaces.
Print the largest value in the array.

Example
Input:
5
3 9 2 7 5
Output: 9`,
      starterCode: `import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int[] values = new int[n];
        for (int i = 0; i < n; i++) {
            values[i] = scanner.nextInt();
        }
        // TODO: find and print the maximum value
    }
}
`,
      entryClass: 'Main',
      testCases: [
        { stdin: '5\n3 9 2 7 5\n', expected: '9', hidden: false },
        { stdin: '1\n42\n', expected: '42', hidden: false },
        { stdin: '4\n-3 -9 -1 -7\n', expected: '-1', hidden: true },
      ],
    },
  },

  {
    order: 7,
    slug: 'methods',
    title: 'Methods',
    summary: 'Break programs into reusable, testable units with parameters, return types, and overloading.',
    bloomLevels: ['Understand', 'Apply', 'Analyze'],
    unlockedByDefault: false,
    theory: `## Declaring a method

    public static int square(int n) {
        return n * n;
    }

The signature is: [access modifier] [static?] [return type] name(parameter
list). return exits the method immediately and hands back a value whose
type must match the declared return type (or void for none).

## Parameters vs. arguments

Parameters are the named placeholders in the declaration (int n above);
arguments are the actual values passed at the call site (square(5) passes
the argument 5). Java is pass-by-value: for primitives, the method gets a
copy, so reassigning a parameter inside the method never affects the
caller's variable.

## Overloading

Two methods can share a name if their parameter lists differ in number or
type — the compiler picks the matching version at compile time:

    static int add(int a, int b) { return a + b; }
    static double add(double a, double b) { return a + b; }

## Why methods matter

Methods are the first real step toward encapsulation and testability: a
well-named method with a single responsibility can be tested in
isolation (exactly how the practical grader here evaluates your code) and
reused instead of copy-pasted.`,
    knowledgeQuestions: [
      {
        type: 'mcq',
        bloom: 'Understand',
        prompt: 'What is the difference between a parameter and an argument?',
        options: [
          'A parameter is the placeholder in the declaration; an argument is the actual value passed at the call site',
          'They are exactly the same thing',
          'A parameter can only be an int; an argument can be any type',
          'An argument is declared, a parameter is passed at the call site',
        ],
        correct: 'A parameter is the placeholder in the declaration; an argument is the actual value passed at the call site',
        points: 1,
      },
      {
        type: 'mcq',
        bloom: 'Apply',
        prompt: 'What keyword immediately exits a method and hands back a value?',
        options: ['return', 'break', 'exit', 'yield'],
        correct: 'return',
        points: 1,
      },
      {
        type: 'mcq',
        bloom: 'Analyze',
        prompt: 'Which pair of method declarations is a VALID example of overloading?',
        options: [
          'int add(int a, int b) and double add(double a, double b)',
          'int add(int a, int b) and int add(int x, int y)',
          'int add(int a, int b) and void add(int a, int b)',
          'int add(int a, int b) declared twice identically',
        ],
        correct: 'int add(int a, int b) and double add(double a, double b)',
        points: 1,
      },
      {
        type: 'enumeration',
        bloom: 'Remember',
        prompt: 'List the parts of a method signature covered in this lesson (access modifier, and three more).',
        correct: ['access modifier', 'static keyword (optional)', 'return type', 'name and parameter list'],
        points: 4,
      },
    ],
    codingChallenge: {
      bloom: 'Create',
      title: 'Implement isPrime',
      prompt: `Complete the method "isPrime(int n)" so it returns true if n is a prime
number (n > 1 and only divisible by 1 and itself) and false otherwise.
Then, in main, read an integer and print "PRIME" or "NOT PRIME"
accordingly by calling your method.

Example
Input:  17
Output: PRIME`,
      starterCode: `import java.util.Scanner;

public class Main {

    static boolean isPrime(int n) {
        // TODO: implement primality check
        return false;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        System.out.println(isPrime(n) ? "PRIME" : "NOT PRIME");
    }
}
`,
      entryClass: 'Main',
      testCases: [
        { stdin: '17\n', expected: 'PRIME', hidden: false },
        { stdin: '10\n', expected: 'NOT PRIME', hidden: false },
        { stdin: '2\n', expected: 'PRIME', hidden: true },
      ],
    },
  },

  {
    order: 8,
    slug: 'oop-intro',
    title: 'OOP Introduction: Classes & Objects',
    summary: 'Model real-world entities as classes with fields and behavior, and instantiate objects from them.',
    bloomLevels: ['Understand', 'Apply'],
    unlockedByDefault: false,
    theory: `## Classes as blueprints

A class is a blueprint describing the fields (state) and methods
(behavior) that its objects will have. An object is one instance created
from that blueprint via new:

    public class Student {
        String name;
        int age;

        void introduce() {
            System.out.println("Hi, I'm " + name);
        }
    }

    Student s1 = new Student();
    s1.name = "Ada";
    s1.introduce();

## Constructors

A constructor initializes a new object's fields at creation time. If you
don't write one, Java supplies a no-argument default constructor:

    public class Student {
        String name;
        int age;

        Student(String name, int age) {
            this.name = name;
            this.age = age;
        }
    }

    Student s1 = new Student("Ada", 17);

this refers to the current object, disambiguating a field from a
parameter of the same name.

## Object-oriented programming, in one line

OOP organizes programs around objects that bundle data with the
operations on that data, instead of a long procedural list of steps
operating on loose variables. Everything in the next four lessons —
encapsulation, inheritance, polymorphism, abstraction — builds directly
on the class/object relationship introduced here.`,
    knowledgeQuestions: [
      {
        type: 'mcq',
        bloom: 'Understand',
        prompt: 'What is the relationship between a class and an object?',
        options: [
          'A class is the blueprint; an object is an instance created from it',
          'They are interchangeable terms',
          'An object is the blueprint; a class is an instance',
          'A class can only ever produce one object',
        ],
        correct: 'A class is the blueprint; an object is an instance created from it',
        points: 1,
      },
      {
        type: 'mcq',
        bloom: 'Apply',
        prompt: 'What keyword creates a new object instance?',
        options: ['new', 'create', 'this', 'instance'],
        correct: 'new',
        points: 1,
      },
      {
        type: 'mcq',
        bloom: 'Understand',
        prompt: 'Inside a constructor, what does the "this" keyword refer to?',
        options: [
          'The object currently being constructed',
          'The parent class',
          'The static context of the class',
          'The previous object created',
        ],
        correct: 'The object currently being constructed',
        points: 1,
      },
      {
        type: 'enumeration',
        bloom: 'Remember',
        prompt: 'Name the two things a class bundles together, per the OOP definition in this lesson.',
        correct: ['data (fields/state)', 'behavior (methods)'],
        points: 2,
      },
    ],
    codingChallenge: {
      bloom: 'Apply',
      title: 'Build a Rectangle Class',
      prompt: `Complete the Rectangle class with a constructor that takes width and
height, and a method area() returning their product as an int. In main,
read width and height, construct a Rectangle, and print its area.

Example
Input:  4 5
Output: 20`,
      starterCode: `import java.util.Scanner;

class Rectangle {
    int width;
    int height;

    Rectangle(int width, int height) {
        // TODO: assign fields using this.
    }

    int area() {
        // TODO: return width * height
        return 0;
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int w = scanner.nextInt();
        int h = scanner.nextInt();
        Rectangle r = new Rectangle(w, h);
        System.out.println(r.area());
    }
}
`,
      entryClass: 'Main',
      testCases: [
        { stdin: '4 5\n', expected: '20', hidden: false },
        { stdin: '1 1\n', expected: '1', hidden: false },
        { stdin: '7 3\n', expected: '21', hidden: true },
      ],
    },
  },

  {
    order: 9,
    slug: 'encapsulation',
    title: 'Encapsulation',
    summary: 'Protect object state behind private fields and controlled public getters/setters.',
    bloomLevels: ['Understand', 'Apply', 'Analyze'],
    unlockedByDefault: false,
    theory: `## Hiding state

Encapsulation means keeping a class's fields private and exposing
controlled access through public methods (getters/setters). This
prevents external code from putting an object into an invalid state:

    public class BankAccount {
        private double balance;

        public double getBalance() {
            return balance;
        }

        public void deposit(double amount) {
            if (amount > 0) {
                balance += amount;
            }
        }
    }

Without encapsulation, any code anywhere could set balance to a negative
number directly. With it, deposit() is the only door in, and it can
enforce the rule that amount must be positive.

## Access modifiers

    private    -> visible only inside the same class
    (default)  -> visible within the same package
    protected  -> visible to the package and subclasses (see Inheritance)
    public     -> visible everywhere

## Why this matters for larger systems

As a codebase grows, encapsulation is what lets you change how a class
stores its data internally without breaking every other class that uses
it — as long as the public method signatures stay the same, callers never
notice the internal change. This is the foundation the progression engine
in this very platform relies on: UserProgress state changes only through
controlled service methods, never by external code writing rows directly.`,
    knowledgeQuestions: [
      {
        type: 'mcq',
        bloom: 'Understand',
        prompt: 'What is the primary goal of encapsulation?',
        options: [
          'Protecting an object\'s internal state from invalid external modification',
          'Making all fields public for easy access',
          'Allowing a class to inherit from multiple parents',
          'Reducing the number of methods in a class',
        ],
        correct: 'Protecting an object\'s internal state from invalid external modification',
        points: 1,
      },
      {
        type: 'mcq',
        bloom: 'Apply',
        prompt: 'Which access modifier restricts a field to be visible only within its own class?',
        options: ['private', 'public', 'protected', 'static'],
        correct: 'private',
        points: 1,
      },
      {
        type: 'mcq',
        bloom: 'Analyze',
        prompt: 'A BankAccount class exposes "public double balance;" directly instead of using a getter/setter. What is the main risk?',
        options: [
          'External code can set balance to any value, including invalid ones, bypassing business rules',
          'The program will fail to compile',
          'The field can no longer be read',
          'There is no risk, this is equivalent to using accessors',
        ],
        correct: 'External code can set balance to any value, including invalid ones, bypassing business rules',
        points: 1,
      },
      {
        type: 'enumeration',
        bloom: 'Remember',
        prompt: 'List the four Java access modifiers covered in this lesson, from most to least restrictive (private, then two more, then public).',
        correct: ['private', 'default (package-private)', 'protected', 'public'],
        points: 4,
      },
    ],
    codingChallenge: {
      bloom: 'Apply',
      title: 'Encapsulated Bank Account',
      prompt: `Complete the BankAccount class: keep balance private, provide deposit(int
amount) that only applies positive amounts, and getBalance(). In main,
read a starting balance and a deposit amount, apply the deposit, and
print the resulting balance. If the deposit amount is not positive, the
balance should be unchanged.

Example
Input:  100 50
Output: 150`,
      starterCode: `import java.util.Scanner;

class BankAccount {
    private int balance;

    BankAccount(int startingBalance) {
        this.balance = startingBalance;
    }

    void deposit(int amount) {
        // TODO: only add amount if it is positive
    }

    int getBalance() {
        return balance;
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int start = scanner.nextInt();
        int deposit = scanner.nextInt();
        BankAccount acc = new BankAccount(start);
        acc.deposit(deposit);
        System.out.println(acc.getBalance());
    }
}
`,
      entryClass: 'Main',
      testCases: [
        { stdin: '100 50\n', expected: '150', hidden: false },
        { stdin: '200 -30\n', expected: '200', hidden: false },
        { stdin: '0 0\n', expected: '0', hidden: true },
      ],
    },
  },

  {
    order: 10,
    slug: 'inheritance',
    title: 'Inheritance',
    summary: 'Share and specialize behavior between classes with extends and super.',
    bloomLevels: ['Understand', 'Apply', 'Analyze'],
    unlockedByDefault: false,
    theory: `## extends

Inheritance lets a subclass reuse the fields and methods of a superclass,
and add or override its own:

    class Animal {
        String name;
        Animal(String name) { this.name = name; }
        void speak() { System.out.println(name + " makes a sound"); }
    }

    class Dog extends Animal {
        Dog(String name) { super(name); }
        void speak() { System.out.println(name + " barks"); }
    }

Dog "is-a" Animal — this relationship is the litmus test for whether
inheritance is the right tool: prefer it only when the subclass really is
a more specific version of the superclass, not just because it happens to
reuse some fields.

## super

super(name) calls the superclass's constructor, and must be the first
statement in the subclass constructor if used. super.methodName() calls
the superclass's version of a method the subclass has overridden.

## Overriding vs. hiding

A subclass overrides a method by redeclaring it with the identical
signature. The @Override annotation is not required but is strongly
recommended — it makes the compiler verify you actually matched a real
superclass method, catching typos that would otherwise silently create an
unrelated new method instead of overriding anything.

## Single inheritance

A Java class extends exactly one superclass (no multiple inheritance of
classes), though it may implement multiple interfaces — a distinction
that matters more once you reach Abstraction.`,
    knowledgeQuestions: [
      {
        type: 'mcq',
        bloom: 'Understand',
        prompt: 'What keyword establishes an inheritance relationship between two classes?',
        options: ['extends', 'implements', 'inherits', 'super'],
        correct: 'extends',
        points: 1,
      },
      {
        type: 'mcq',
        bloom: 'Apply',
        prompt: 'What must be the first statement in a subclass constructor if it explicitly calls the superclass constructor?',
        options: ['super(...)', 'this(...)', 'new Superclass()', 'It can appear anywhere'],
        correct: 'super(...)',
        points: 1,
      },
      {
        type: 'mcq',
        bloom: 'Analyze',
        prompt: 'How many classes can a single Java class directly extend?',
        options: ['Exactly one', 'Zero or more, any number', 'Exactly two', 'Unlimited, like interfaces'],
        correct: 'Exactly one',
        points: 1,
      },
      {
        type: 'enumeration',
        bloom: 'Remember',
        prompt: 'Name the two things the "super" keyword can be used to call, as covered in this lesson.',
        correct: ['the superclass constructor', "the superclass's version of an overridden method"],
        points: 2,
      },
    ],
    codingChallenge: {
      bloom: 'Analyze',
      title: 'Animal Sounds',
      prompt: `Complete the Dog and Cat subclasses of Animal so their speak() methods
override the parent to print "<name> barks" and "<name> meows"
respectively. In main, read a name and a type ("dog" or "cat"), construct
the right subclass, and call speak().

Example
Input:  Rex dog
Output: Rex barks`,
      starterCode: `import java.util.Scanner;

class Animal {
    String name;
    Animal(String name) { this.name = name; }
    void speak() { System.out.println(name + " makes a sound"); }
}

class Dog extends Animal {
    Dog(String name) { super(name); }
    // TODO: override speak() to print "<name> barks"
}

class Cat extends Animal {
    Cat(String name) { super(name); }
    // TODO: override speak() to print "<name> meows"
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String name = scanner.next();
        String type = scanner.next();
        Animal a = type.equals("dog") ? new Dog(name) : new Cat(name);
        a.speak();
    }
}
`,
      entryClass: 'Main',
      testCases: [
        { stdin: 'Rex dog\n', expected: 'Rex barks', hidden: false },
        { stdin: 'Whiskers cat\n', expected: 'Whiskers meows', hidden: false },
        { stdin: 'Buddy dog\n', expected: 'Buddy barks', hidden: true },
      ],
    },
  },

  {
    order: 11,
    slug: 'polymorphism',
    title: 'Polymorphism',
    summary: 'Treat objects of different subclasses uniformly through a shared superclass reference.',
    bloomLevels: ['Understand', 'Apply', 'Analyze'],
    unlockedByDefault: false,
    theory: `## Runtime polymorphism

Polymorphism ("many forms") lets a superclass-typed reference call an
overridden method and have the actual subclass's version run, decided at
runtime, not at compile time:

    Animal a = new Dog("Rex");
    a.speak();   // prints "Rex barks", NOT "Rex makes a sound"

Even though the variable a is declared as type Animal, the JVM looks at
the real object's class (Dog) when speak() is called. This is what makes
a loop like the one below work uniformly over mixed subclasses:

    Animal[] animals = { new Dog("Rex"), new Cat("Milo") };
    for (Animal a : animals) {
        a.speak();   // each call dispatches to the correct override
    }

## Method overriding vs. overloading, revisited

Overriding (same signature, subclass redefines behavior) is what enables
polymorphism. Overloading (same name, different parameter list, from
Methods) is resolved at compile time based on the declared argument
types — a different mechanism that is easy to confuse with overriding but
serves a different purpose.

## Why it matters

Polymorphism is what lets you write code against a general type (Animal,
Shape, PaymentMethod) and have it correctly handle every specific
subclass without an if/else-if chain checking each concrete type by hand
— new subclasses can be added later without touching the calling code.`,
    knowledgeQuestions: [
      {
        type: 'mcq',
        bloom: 'Understand',
        prompt: 'Given "Animal a = new Dog(\\"Rex\\"); a.speak();" where Dog overrides speak(), which version runs?',
        options: [
          "Dog's overridden version, decided at runtime",
          "Animal's version, decided at compile time",
          'Both versions run in sequence',
          'A compile error occurs',
        ],
        correct: "Dog's overridden version, decided at runtime",
        points: 1,
      },
      {
        type: 'mcq',
        bloom: 'Analyze',
        prompt: 'What is the key mechanical difference between overriding and overloading?',
        options: [
          'Overriding keeps the same signature and is resolved at runtime; overloading changes the parameter list and is resolved at compile time',
          'They are two names for the exact same mechanism',
          'Overloading only works across different classes; overriding only works within one class',
          'Overriding requires a static method; overloading requires an instance method',
        ],
        correct: 'Overriding keeps the same signature and is resolved at runtime; overloading changes the parameter list and is resolved at compile time',
        points: 1,
      },
      {
        type: 'mcq',
        bloom: 'Apply',
        prompt: 'Why does looping over an Animal[] containing Dog and Cat objects and calling speak() avoid an if/else chain per type?',
        options: [
          'Polymorphic dispatch automatically routes each call to the correct subclass override',
          'Java automatically sorts the array by type first',
          'Dog and Cat share the exact same speak() implementation',
          'The compiler inlines all subclasses into one method',
        ],
        correct: 'Polymorphic dispatch automatically routes each call to the correct subclass override',
        points: 1,
      },
      {
        type: 'enumeration',
        bloom: 'Remember',
        prompt: 'Name the two method mechanisms this lesson contrasts: one enables polymorphism (same signature, redefined), the other varies by parameter list.',
        correct: ['overriding', 'overloading'],
        points: 2,
      },
    ],
    codingChallenge: {
      bloom: 'Create',
      title: 'Shape Areas via Polymorphism',
      prompt: `Complete Circle and Square, both extending Shape, so each overrides
area() correctly (Circle: pi * r * r using Math.PI; Square: side * side).
In main, read a type ("circle" or "square") and a dimension (radius or
side, as a double), construct the right Shape, and print area() rounded
to 2 decimal places with System.out.printf("%.2f%n", ...).

Example
Input:  circle 2
Output: 12.57`,
      starterCode: `import java.util.Scanner;

abstract class Shape {
    abstract double area();
}

class Circle extends Shape {
    double radius;
    Circle(double radius) { this.radius = radius; }
    // TODO: override area() -> Math.PI * radius * radius
    double area() { return 0; }
}

class Square extends Shape {
    double side;
    Square(double side) { this.side = side; }
    // TODO: override area() -> side * side
    double area() { return 0; }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String type = scanner.next();
        double dim = scanner.nextDouble();
        Shape s = type.equals("circle") ? new Circle(dim) : new Square(dim);
        System.out.printf("%.2f%n", s.area());
    }
}
`,
      entryClass: 'Main',
      testCases: [
        { stdin: 'circle 2\n', expected: '12.57', hidden: false },
        { stdin: 'square 4\n', expected: '16.00', hidden: false },
        { stdin: 'circle 1\n', expected: '3.14', hidden: true },
      ],
    },
  },

  {
    order: 12,
    slug: 'abstraction',
    title: 'Abstraction',
    summary: 'Define contracts with abstract classes and interfaces, hiding implementation behind a shared shape.',
    bloomLevels: ['Understand', 'Apply', 'Analyze', 'Evaluate'],
    unlockedByDefault: false,
    theory: `## Abstract classes

An abstract class can declare methods with no body (abstract methods),
forcing every concrete subclass to supply an implementation. It cannot be
instantiated directly with new:

    abstract class Shape {
        abstract double area();          // no body — a contract
        void describe() {                // a normal, shared method
            System.out.println("Area = " + area());
        }
    }

## Interfaces

An interface is a purer contract: (traditionally) only method signatures,
no state, no implementation. A class can implement multiple interfaces
even though it can extend only one class:

    interface Payable {
        double calculatePay();
    }

    class Employee implements Payable {
        public double calculatePay() { return 50000; }
    }

## Abstract class vs. interface — when to use which

Reach for an abstract class when subclasses share common state or partial
implementation (like describe() above). Reach for an interface when you
need to describe a capability that unrelated classes can all promise to
support, regardless of their position in the class hierarchy — e.g. both
an Employee and a Contract can implement Payable without being related by
inheritance at all.

## Abstraction as the capstone of OOP

Abstraction ties the previous three pillars together: encapsulation hides
data, inheritance shares structure, polymorphism dispatches behavior at
runtime, and abstraction is the decision to expose only the essential
contract (what a Shape can do) while hiding exactly how each concrete
shape computes it.`,
    knowledgeQuestions: [
      {
        type: 'mcq',
        bloom: 'Understand',
        prompt: 'Can an abstract class be instantiated directly with "new"?',
        options: ['No, never', 'Yes, always', 'Only if it has no abstract methods left unimplemented by itself', 'Only inside its own package'],
        correct: 'No, never',
        points: 1,
      },
      {
        type: 'mcq',
        bloom: 'Analyze',
        prompt: 'A class needs to share common state AND force a contract across several related subclasses. Which is the better fit?',
        options: ['An abstract class', 'An interface', 'Neither can do this', 'A private inner class'],
        correct: 'An abstract class',
        points: 1,
      },
      {
        type: 'mcq',
        bloom: 'Evaluate',
        prompt: 'Two unrelated classes, Employee and Contract, both need to guarantee a calculatePay() method but share no common state or hierarchy. What is the more appropriate abstraction tool?',
        options: ['An interface', 'An abstract class', 'A single shared concrete superclass', 'A static utility class'],
        correct: 'An interface',
        points: 1,
      },
      {
        type: 'enumeration',
        bloom: 'Remember',
        prompt: 'Name the two Java language constructs this lesson uses to achieve abstraction.',
        correct: ['abstract class', 'interface'],
        points: 2,
      },
    ],
    codingChallenge: {
      bloom: 'Create',
      title: 'Payable Interface',
      prompt: `Define an interface Payable with method double calculatePay(). Implement
it in class Employee (fields: baseSalary, bonus -> calculatePay returns
their sum) and class Freelancer (fields: hourlyRate, hoursWorked ->
calculatePay returns their product). In main, read a type ("employee" or
"freelancer") and two numbers, construct the right implementation, and
print calculatePay() with 2 decimal places.

Example
Input:  employee 50000 2000
Output: 52000.00`,
      starterCode: `import java.util.Scanner;

interface Payable {
    double calculatePay();
}

class Employee implements Payable {
    double baseSalary;
    double bonus;
    Employee(double baseSalary, double bonus) {
        this.baseSalary = baseSalary;
        this.bonus = bonus;
    }
    // TODO: implement calculatePay() -> baseSalary + bonus
    public double calculatePay() { return 0; }
}

class Freelancer implements Payable {
    double hourlyRate;
    double hoursWorked;
    Freelancer(double hourlyRate, double hoursWorked) {
        this.hourlyRate = hourlyRate;
        this.hoursWorked = hoursWorked;
    }
    // TODO: implement calculatePay() -> hourlyRate * hoursWorked
    public double calculatePay() { return 0; }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String type = scanner.next();
        double x = scanner.nextDouble();
        double y = scanner.nextDouble();
        Payable p = type.equals("employee") ? new Employee(x, y) : new Freelancer(x, y);
        System.out.printf("%.2f%n", p.calculatePay());
    }
}
`,
      entryClass: 'Main',
      testCases: [
        { stdin: 'employee 50000 2000\n', expected: '52000.00', hidden: false },
        { stdin: 'freelancer 25 40\n', expected: '1000.00', hidden: false },
        { stdin: 'employee 0 0\n', expected: '0.00', hidden: true },
      ],
    },
  },
];
