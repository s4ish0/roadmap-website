/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        // Design tokens — an IDE/terminal identity, not a marketing landing
        // page: the whole app reads like a dark editor, with an amber accent
        // that nods to Java's coffee-cup mark rather than a generic brand hue.
        ink: {
          950: '#0B0D11',
          900: '#12151B',
          800: '#171B22',
          700: '#1F242D',
          600: '#262B35',
          500: '#343B48',
        },
        mist: {
          400: '#6B7280',
          300: '#9AA3B2',
          200: '#C3C9D4',
          100: '#E7E9EE',
        },
        brew: {
          // "brew" = the amber/coffee accent (Java = coffee)
          400: '#F2A93C',
          500: '#E8A33D',
          600: '#C7822A',
        },
        compile: {
          // teal used for pass/success/unlocked states
          400: '#5EEAD4',
          500: '#4FD1C5',
          600: '#2CA89D',
        },
        fail: {
          400: '#F87171',
          500: '#E5484D',
          600: '#B91C1C',
        },
      },
      fontFamily: {
        mono: ['"JetBrains Mono"', 'ui-monospace', 'SFMono-Regular', 'Menlo', 'monospace'],
        sans: ['"Inter"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        node: '0 0 0 1px rgba(242,169,60,0.15), 0 8px 24px -12px rgba(0,0,0,0.6)',
      },
    },
  },
  plugins: [],
};
