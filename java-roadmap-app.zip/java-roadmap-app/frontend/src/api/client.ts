import type {
  RoadmapResponse,
  LessonDetail,
  RunResult,
  SubmitResult,
  KnowledgeSubmitResult,
  AuthUser,
} from '../types';

const TOKEN_KEY = 'java_roadmap_token';

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}
export function setToken(token: string) {
  localStorage.setItem(TOKEN_KEY, token);
}
export function clearToken() {
  localStorage.removeItem(TOKEN_KEY);
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getToken();
  const res = await fetch(`/api${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers || {}),
    },
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error((data as any).error || `Request failed (${res.status})`);
  }
  return data as T;
}

export const api = {
  register: (body: { username: string; email: string; password: string; displayName?: string }) =>
    request<{ token: string; user: AuthUser }>('/auth/register', { method: 'POST', body: JSON.stringify(body) }),

  login: (body: { username: string; password: string }) =>
    request<{ token: string; user: AuthUser }>('/auth/login', { method: 'POST', body: JSON.stringify(body) }),

  getRoadmap: () => request<RoadmapResponse>('/lessons'),

  getLesson: (lessonId: number) => request<LessonDetail>(`/lessons/${lessonId}`),

  submitKnowledgeTest: (lessonId: number, answers: Record<string, string | string[]>) =>
    request<KnowledgeSubmitResult>(`/lessons/${lessonId}/knowledge-test/submit`, {
      method: 'POST',
      body: JSON.stringify({ answers }),
    }),

  runPractical: (lessonId: number, code: string) =>
    request<RunResult>(`/lessons/${lessonId}/practical/run`, {
      method: 'POST',
      body: JSON.stringify({ code }),
    }),

  submitPractical: (lessonId: number, code: string) =>
    request<SubmitResult>(`/lessons/${lessonId}/practical/submit`, {
      method: 'POST',
      body: JSON.stringify({ code }),
    }),
};
