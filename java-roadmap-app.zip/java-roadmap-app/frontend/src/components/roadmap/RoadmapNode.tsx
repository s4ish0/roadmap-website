import React from 'react';
import { useNavigate } from 'react-router-dom';
import clsx from 'clsx';
import { Lock, Check, CircleDot } from 'lucide-react';
import type { RoadmapLesson } from '../../types';

interface Props {
  lesson: RoadmapLesson;
  compact?: boolean;
  active?: boolean;
}

const STATUS_META: Record<RoadmapLesson['status'], { label: string; icon: React.ReactNode; ring: string; text: string }> = {
  locked: { label: 'Locked', icon: <Lock size={13} />, ring: 'ring-ink-600', text: 'text-mist-400' },
  unlocked: { label: 'Ready', icon: <CircleDot size={13} />, ring: 'ring-brew-500/60', text: 'text-brew-400' },
  in_progress: { label: 'In progress', icon: <CircleDot size={13} />, ring: 'ring-brew-500/60', text: 'text-brew-400' },
  completed: { label: 'Passed', icon: <Check size={13} />, ring: 'ring-compile-500/60', text: 'text-compile-400' },
};

export default function RoadmapNode({ lesson, compact = false, active = false }: Props) {
  const navigate = useNavigate();
  const meta = STATUS_META[lesson.status];
  const isLocked = lesson.status === 'locked';

  return (
    <button
      type="button"
      disabled={isLocked}
      onClick={() => !isLocked && navigate(`/lesson/${lesson.id}`)}
      className={clsx(
        'group w-full rounded-lg border text-left transition',
        'border-ink-600 bg-ink-800 ring-1',
        meta.ring,
        isLocked ? 'cursor-not-allowed opacity-60' : 'hover:-translate-y-0.5 hover:border-brew-500/50 hover:shadow-node',
        active && 'border-brew-500 shadow-node',
        compact ? 'px-3 py-2.5' : 'px-5 py-4'
      )}
    >
      {/* terminal window chrome */}
      <div className="mb-2 flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <span className="h-2 w-2 rounded-full bg-fail-500/70" />
          <span className="h-2 w-2 rounded-full bg-brew-500/70" />
          <span className="h-2 w-2 rounded-full bg-compile-500/70" />
        </div>
        <span className={clsx('flex items-center gap-1 font-mono text-[10px] uppercase tracking-wide', meta.text)}>
          {meta.icon}
          {meta.label}
        </span>
      </div>

      <p className={clsx('font-mono text-mist-400', compact ? 'text-[11px]' : 'text-xs')}>
        $ lesson-{String(lesson.order).padStart(2, '0')}-{lesson.slug}
      </p>
      <h3 className={clsx('mt-1 font-semibold text-mist-100', compact ? 'text-sm' : 'text-lg')}>{lesson.title}</h3>

      {!compact && <p className="mt-1.5 text-sm text-mist-300">{lesson.summary}</p>}

      {!compact && (
        <div className="mt-3 flex flex-wrap gap-1.5">
          {lesson.bloomLevels.map((b) => (
            <span
              key={b}
              className="rounded-full border border-ink-600 bg-ink-900 px-2 py-0.5 font-mono text-[10px] text-mist-300"
            >
              {b}
            </span>
          ))}
        </div>
      )}

      {!compact && lesson.status !== 'locked' && (
        <div className="mt-3 flex gap-4 font-mono text-[11px] text-mist-400">
          <span>
            Knowledge:{' '}
            <span className={lesson.knowledgePassed ? 'text-compile-400' : 'text-mist-300'}>
              {lesson.knowledgeScore != null ? `${Math.round(lesson.knowledgeScore * 100)}%` : '—'}
            </span>
          </span>
          <span>
            Practical:{' '}
            <span className={lesson.practicalPassed ? 'text-compile-400' : 'text-mist-300'}>
              {lesson.practicalScore != null ? `${Math.round(lesson.practicalScore * 100)}%` : '—'}
            </span>
          </span>
        </div>
      )}
    </button>
  );
}
