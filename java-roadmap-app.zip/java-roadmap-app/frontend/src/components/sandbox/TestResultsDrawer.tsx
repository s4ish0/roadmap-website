import React from 'react';
import { CheckCircle2, XCircle, Clock, Lock } from 'lucide-react';
import clsx from 'clsx';

export interface TestResultRow {
  testCaseId: number;
  passed: boolean;
  timedOut?: boolean;
  hidden?: boolean;
  stdout?: string;
  stderr?: string;
}

export default function TestResultsDrawer({ results }: { results: TestResultRow[] }) {
  if (results.length === 0) return null;

  return (
    <div className="overflow-hidden rounded-lg border border-ink-600">
      <div className="border-b border-ink-600 bg-ink-800 px-3 py-2 font-mono text-xs text-mist-400">
        Test Cases — {results.filter((r) => r.passed).length}/{results.length} passed
      </div>
      <ul className="divide-y divide-ink-600">
        {results.map((r, idx) => (
          <li key={r.testCaseId ?? idx} className="flex items-start gap-2.5 px-3 py-2.5">
            {r.passed ? (
              <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-compile-400" />
            ) : r.timedOut ? (
              <Clock size={16} className="mt-0.5 shrink-0 text-brew-400" />
            ) : (
              <XCircle size={16} className="mt-0.5 shrink-0 text-fail-400" />
            )}
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs text-mist-200">Test case {idx + 1}</span>
                {r.hidden && (
                  <span className="flex items-center gap-1 rounded-full border border-ink-600 px-1.5 py-0.5 font-mono text-[10px] text-mist-400">
                    <Lock size={9} /> hidden
                  </span>
                )}
                {r.timedOut && (
                  <span className="rounded-full border border-brew-500/40 bg-brew-500/10 px-1.5 py-0.5 font-mono text-[10px] text-brew-400">
                    timed out
                  </span>
                )}
              </div>
              {!r.hidden && !r.passed && r.stderr && (
                <pre className="mt-1 max-h-24 overflow-auto whitespace-pre-wrap font-mono text-[11px] text-fail-400">
                  {r.stderr}
                </pre>
              )}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
