import React from 'react';
import { TerminalSquare } from 'lucide-react';

interface Props {
  stdout?: string;
  stderr?: string;
  compileError?: boolean;
  placeholder?: string;
}

export default function OutputPanel({ stdout, stderr, compileError, placeholder }: Props) {
  const hasOutput = !!(stdout || stderr);

  return (
    <div className="overflow-hidden rounded-lg border border-ink-600">
      <div className="flex items-center gap-2 border-b border-ink-600 bg-ink-800 px-3 py-2">
        <TerminalSquare size={14} className="text-mist-400" />
        <span className="font-mono text-xs text-mist-400">
          {compileError ? 'Compiler output' : 'stdout / stderr'}
        </span>
      </div>
      <pre className="max-h-56 min-h-[6rem] overflow-auto whitespace-pre-wrap bg-ink-950 p-3 font-mono text-xs leading-relaxed text-mist-200">
        {hasOutput ? (
          <>
            {stdout && <span className="text-mist-200">{stdout}</span>}
            {stderr && <span className="text-fail-400">{stdout ? '\n' : ''}{stderr}</span>}
          </>
        ) : (
          <span className="text-mist-400">{placeholder || 'Run your code to see output here.'}</span>
        )}
      </pre>
    </div>
  );
}
