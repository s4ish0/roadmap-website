import React from 'react';
import Editor from '@monaco-editor/react';

interface Props {
  value: string;
  onChange: (value: string) => void;
  height?: string;
  readOnly?: boolean;
}

export default function CodeEditor({ value, onChange, height = '420px', readOnly = false }: Props) {
  return (
    <div className="overflow-hidden rounded-lg border border-ink-600">
      <div className="flex items-center gap-1.5 border-b border-ink-600 bg-ink-800 px-3 py-2">
        <span className="h-2.5 w-2.5 rounded-full bg-fail-500/70" />
        <span className="h-2.5 w-2.5 rounded-full bg-brew-500/70" />
        <span className="h-2.5 w-2.5 rounded-full bg-compile-500/70" />
        <span className="ml-2 font-mono text-xs text-mist-400">Main.java</span>
      </div>
      <Editor
        height={height}
        defaultLanguage="java"
        theme="vs-dark"
        value={value}
        onChange={(v) => onChange(v ?? '')}
        options={{
          fontFamily: 'JetBrains Mono, monospace',
          fontSize: 13.5,
          minimap: { enabled: false },
          scrollBeyondLastLine: false,
          readOnly,
          tabSize: 4,
          automaticLayout: true,
          padding: { top: 12 },
        }}
      />
    </div>
  );
}
