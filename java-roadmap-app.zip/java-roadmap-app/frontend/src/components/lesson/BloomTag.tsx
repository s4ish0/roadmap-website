import React from 'react';
import clsx from 'clsx';

// Bloom's six levels, ordered lowest -> highest cognitive demand. Color
// intensity increases with the level so the pill itself communicates depth,
// not just the label.
const ORDER = ['Remember', 'Understand', 'Apply', 'Analyze', 'Evaluate', 'Create'];
const COLORS: Record<string, string> = {
  Remember: 'bg-ink-700 text-mist-300 border-ink-600',
  Understand: 'bg-ink-700 text-mist-200 border-ink-600',
  Apply: 'bg-brew-500/10 text-brew-400 border-brew-500/30',
  Analyze: 'bg-brew-500/15 text-brew-400 border-brew-500/40',
  Evaluate: 'bg-compile-500/10 text-compile-400 border-compile-500/30',
  Create: 'bg-compile-500/15 text-compile-400 border-compile-500/40',
};

export default function BloomTag({ level }: { level: string }) {
  return (
    <span
      className={clsx(
        'inline-flex items-center gap-1 rounded-full border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wide',
        COLORS[level] || 'bg-ink-700 text-mist-300 border-ink-600'
      )}
      title={`Bloom's Taxonomy: ${level} (level ${ORDER.indexOf(level) + 1} of 6)`}
    >
      {level}
    </span>
  );
}
