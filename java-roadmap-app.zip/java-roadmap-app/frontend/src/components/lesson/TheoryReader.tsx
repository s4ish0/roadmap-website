import React from 'react';
import ReactMarkdown from 'react-markdown';
import BloomTag from './BloomTag';

interface Props {
  title: string;
  summary: string;
  bloomLevels: string[];
  markdown: string;
}

export default function TheoryReader({ title, summary, bloomLevels, markdown }: Props) {
  return (
    <div>
      <div className="mb-5">
        <h1 className="text-2xl font-bold text-mist-100">{title}</h1>
        <p className="mt-1 text-sm text-mist-300">{summary}</p>
        <div className="mt-3 flex flex-wrap gap-1.5">
          {bloomLevels.map((b) => (
            <BloomTag key={b} level={b} />
          ))}
        </div>
      </div>

      <div className="theory-content">
        <ReactMarkdown
          components={{
            // Indented code blocks (4-space) render as <pre><code> by default
            // in remark, which matches the terminal aesthetic without extra
            // syntax-highlighting weight for a reference reading view.
            h2: ({ children }) => <h2>{children}</h2>,
          }}
        >
          {markdown}
        </ReactMarkdown>
      </div>
    </div>
  );
}
