import React, { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import clsx from 'clsx';
import RoadmapNode from '../roadmap/RoadmapNode';
import type { RoadmapLesson } from '../../types';

interface Props {
  lessons: RoadmapLesson[];
  activeLessonId: number;
}

export default function Sidebar({ lessons, activeLessonId }: Props) {
  const [collapsed, setCollapsed] = useState(false);
  const navigate = useNavigate();

  return (
    <aside
      className={clsx(
        'sticky top-16 h-[calc(100vh-4rem)] shrink-0 overflow-y-auto border-r border-ink-600 bg-ink-900 transition-all',
        collapsed ? 'w-14' : 'w-72'
      )}
    >
      <div className="flex items-center justify-between px-3 py-3">
        {!collapsed && <span className="font-mono text-xs uppercase tracking-wide text-mist-400">Lessons</span>}
        <button
          onClick={() => setCollapsed((c) => !c)}
          className="flex h-7 w-7 items-center justify-center rounded-md border border-ink-600 text-mist-300 hover:border-brew-500/50 hover:text-brew-400"
          title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {collapsed ? <ChevronRight size={14} /> : <ChevronLeft size={14} />}
        </button>
      </div>

      <div className={clsx('space-y-2 px-3 pb-6', collapsed && 'px-2')}>
        {lessons.map((lesson) =>
          collapsed ? (
            <button
              key={lesson.id}
              disabled={lesson.status === 'locked'}
              onClick={() => lesson.status !== 'locked' && navigate(`/lesson/${lesson.id}`)}
              className={clsx(
                'flex h-9 w-9 items-center justify-center rounded-md border font-mono text-xs',
                lesson.id === activeLessonId ? 'border-brew-500 text-brew-400' : 'border-ink-600 text-mist-400',
                lesson.status === 'locked' && 'cursor-not-allowed opacity-50'
              )}
              title={lesson.title}
            >
              {String(lesson.order).padStart(2, '0')}
            </button>
          ) : (
            <RoadmapNode key={lesson.id} lesson={lesson} compact active={lesson.id === activeLessonId} />
          )
        )}
      </div>
    </aside>
  );
}
