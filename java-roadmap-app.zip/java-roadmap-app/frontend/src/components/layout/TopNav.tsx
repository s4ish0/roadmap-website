import React from 'react';
import { Link } from 'react-router-dom';
import { Terminal, LogOut } from 'lucide-react';
import { useAuth } from '../../state/AuthContext';
import ProgressBar from './ProgressBar';

interface Props {
  overallProgress?: number; // 0..1, omitted on pages that don't track it
}

export default function TopNav({ overallProgress }: Props) {
  const { user, logout } = useAuth();

  return (
    <header className="sticky top-0 z-30 border-b border-ink-600 bg-ink-900/95 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6">
        <Link to="/" className="flex items-center gap-2">
          <span className="flex h-8 w-8 items-center justify-center rounded-md bg-brew-500/15 text-brew-400">
            <Terminal size={18} strokeWidth={2.25} />
          </span>
          <span className="font-mono text-sm font-semibold tracking-tight text-mist-100">
            java<span className="text-brew-400">.roadmap</span>
          </span>
        </Link>

        <nav className="hidden items-center gap-6 font-mono text-sm text-mist-300 sm:flex">
          <Link to="/" className="transition hover:text-mist-100">
            Home
          </Link>
          <a href="#about" className="transition hover:text-mist-100">
            About
          </a>
        </nav>

        <div className="flex items-center gap-4">
          {typeof overallProgress === 'number' && (
            <div className="hidden w-40 items-center gap-2 md:flex">
              <ProgressBar value={overallProgress} />
              <span className="font-mono text-xs text-mist-300">{Math.round(overallProgress * 100)}%</span>
            </div>
          )}
          {user && (
            <div className="flex items-center gap-3">
              <span className="hidden font-mono text-xs text-mist-300 sm:inline">{user.displayName}</span>
              <button
                onClick={logout}
                className="flex h-8 w-8 items-center justify-center rounded-md border border-ink-600 text-mist-300 transition hover:border-fail-500 hover:text-fail-400"
                title="Log out"
              >
                <LogOut size={15} />
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
