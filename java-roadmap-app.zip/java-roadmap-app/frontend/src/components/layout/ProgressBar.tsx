import React from 'react';
import clsx from 'clsx';

export default function ProgressBar({ value, className }: { value: number; className?: string }) {
  const pct = Math.max(0, Math.min(1, value)) * 100;
  return (
    <div className={clsx('h-1.5 flex-1 overflow-hidden rounded-full bg-ink-600', className)}>
      <div
        className="h-full rounded-full bg-gradient-to-r from-brew-600 to-brew-400 transition-all duration-500"
        style={{ width: `${pct}%` }}
      />
    </div>
  );
}
