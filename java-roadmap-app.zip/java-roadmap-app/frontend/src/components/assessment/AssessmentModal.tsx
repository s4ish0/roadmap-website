import React, { useState } from 'react';
import { X, BookCheck, Code2 } from 'lucide-react';
import clsx from 'clsx';
import KnowledgeTest from './KnowledgeTest';
import PracticalTest from './PracticalTest';
import type { KnowledgeQuestion, CodingChallenge, KnowledgeSubmitResult, SubmitResult } from '../../types';

interface Props {
  lessonId: number;
  knowledgeQuestions: KnowledgeQuestion[];
  codingChallenge: CodingChallenge;
  threshold: number;
  initialTab?: 'knowledge' | 'practical';
  onClose: () => void;
  onKnowledgeGraded: (result: KnowledgeSubmitResult) => void;
  onPracticalGraded: (result: SubmitResult) => void;
}

export default function AssessmentModal({
  lessonId,
  knowledgeQuestions,
  codingChallenge,
  threshold,
  initialTab = 'knowledge',
  onClose,
  onKnowledgeGraded,
  onPracticalGraded,
}: Props) {
  const [tab, setTab] = useState<'knowledge' | 'practical'>(initialTab);

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/70 p-4 py-10 backdrop-blur-sm">
      <div className="w-full max-w-3xl rounded-xl border border-ink-600 bg-ink-900 shadow-node">
        <div className="flex items-center justify-between border-b border-ink-600 px-5 py-4">
          <h2 className="text-base font-semibold text-mist-100">Dual Assessment</h2>
          <button onClick={onClose} className="text-mist-400 hover:text-mist-100">
            <X size={18} />
          </button>
        </div>

        {/* Dual Assessment Toggle Area */}
        <div className="flex gap-1 border-b border-ink-600 bg-ink-800 p-2">
          <button
            onClick={() => setTab('knowledge')}
            className={clsx(
              'flex flex-1 items-center justify-center gap-2 rounded-md py-2 font-mono text-xs uppercase tracking-wide transition',
              tab === 'knowledge' ? 'bg-brew-500 text-ink-950' : 'text-mist-300 hover:bg-ink-700'
            )}
          >
            <BookCheck size={14} /> Knowledge Test
          </button>
          <button
            onClick={() => setTab('practical')}
            className={clsx(
              'flex flex-1 items-center justify-center gap-2 rounded-md py-2 font-mono text-xs uppercase tracking-wide transition',
              tab === 'practical' ? 'bg-brew-500 text-ink-950' : 'text-mist-300 hover:bg-ink-700'
            )}
          >
            <Code2 size={14} /> Practical Test
          </button>
        </div>

        <div className="max-h-[70vh] overflow-y-auto p-5">
          {tab === 'knowledge' ? (
            <KnowledgeTest
              lessonId={lessonId}
              questions={knowledgeQuestions}
              threshold={threshold}
              onGraded={onKnowledgeGraded}
            />
          ) : (
            <PracticalTest
              lessonId={lessonId}
              challenge={codingChallenge}
              initialCode={codingChallenge.starterCode}
              threshold={threshold}
              onGraded={onPracticalGraded}
            />
          )}
        </div>
      </div>
    </div>
  );
}
