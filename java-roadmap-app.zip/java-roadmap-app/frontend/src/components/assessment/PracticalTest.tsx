import React, { useState } from 'react';
import { Loader2, CheckCircle2, XCircle, Send } from 'lucide-react';
import CodeEditor from '../sandbox/CodeEditor';
import OutputPanel from '../sandbox/OutputPanel';
import TestResultsDrawer from '../sandbox/TestResultsDrawer';
import { api } from '../../api/client';
import type { CodingChallenge, SubmitResult } from '../../types';

interface Props {
  lessonId: number;
  challenge: CodingChallenge;
  initialCode: string;
  threshold: number;
  onGraded: (result: SubmitResult) => void;
}

export default function PracticalTest({ lessonId, challenge, initialCode, threshold, onGraded }: Props) {
  const [code, setCode] = useState(initialCode);
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<SubmitResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async () => {
    setSubmitting(true);
    setError(null);
    try {
      const res = await api.submitPractical(lessonId, code);
      setResult(res);
      onGraded(res);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-ink-600 bg-ink-800 p-4">
        <p className="mb-2 font-mono text-xs text-mist-400">
          {challenge.hiddenTestCaseCount > 0 && `${challenge.hiddenTestCaseCount} additional hidden test case(s) will also run on submit.`}
        </p>
        <pre className="whitespace-pre-wrap font-sans text-sm text-mist-200">{challenge.promptMarkdown}</pre>
      </div>

      <CodeEditor value={code} onChange={setCode} height="360px" />

      {error && <p className="text-sm text-fail-400">{error}</p>}

      <button
        onClick={handleSubmit}
        disabled={submitting}
        className="flex items-center gap-2 rounded-md bg-brew-500 px-4 py-2 text-sm font-semibold text-ink-950 transition hover:bg-brew-400 disabled:opacity-60"
      >
        {submitting ? <Loader2 size={14} className="animate-spin" /> : <Send size={14} />}
        Submit Practical Test
      </button>

      {result && (
        <>
          <div
            className={`rounded-lg border p-4 ${
              result.passed ? 'border-compile-500/40 bg-compile-500/10' : 'border-fail-500/40 bg-fail-500/10'
            }`}
          >
            <div className="flex items-center gap-2">
              {result.passed ? (
                <CheckCircle2 size={18} className="text-compile-400" />
              ) : (
                <XCircle size={18} className="text-fail-400" />
              )}
              <p className={`font-semibold ${result.passed ? 'text-compile-400' : 'text-fail-400'}`}>
                {result.passedCount}/{result.totalCount} test cases —{' '}
                {result.passed ? 'Passed' : `Below the ${Math.round(threshold * 100)}% threshold`}
              </p>
            </div>
          </div>

          {result.compileError ? (
            <OutputPanel stderr={result.compileStderr} compileError />
          ) : (
            <TestResultsDrawer results={result.results} />
          )}
        </>
      )}
    </div>
  );
}
