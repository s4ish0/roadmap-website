import React, { useState } from 'react';
import { Loader2, CheckCircle2, XCircle } from 'lucide-react';
import { api } from '../../api/client';
import type { KnowledgeQuestion, KnowledgeSubmitResult } from '../../types';

interface Props {
  lessonId: number;
  questions: KnowledgeQuestion[];
  threshold: number;
  onGraded: (result: KnowledgeSubmitResult) => void;
}

export default function KnowledgeTest({ lessonId, questions, threshold, onGraded }: Props) {
  const [answers, setAnswers] = useState<Record<number, string | string[]>>({});
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<KnowledgeSubmitResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const setMcqAnswer = (qId: number, value: string) => setAnswers((a) => ({ ...a, [qId]: value }));
  const setEnumAnswer = (qId: number, raw: string) =>
    setAnswers((a) => ({ ...a, [qId]: raw.split(/[,\n]/).map((s) => s.trim()).filter(Boolean) }));

  const handleSubmit = async () => {
    setSubmitting(true);
    setError(null);
    try {
      const res = await api.submitKnowledgeTest(lessonId, answers as Record<string, string | string[]>);
      setResult(res);
      onGraded(res);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-5">
      {questions.map((q, idx) => (
        <div key={q.id} className="rounded-lg border border-ink-600 bg-ink-800 p-4">
          <p className="mb-3 text-sm text-mist-100">
            <span className="mr-2 font-mono text-xs text-mist-400">Q{idx + 1}.</span>
            {q.prompt}
            <span className="ml-2 font-mono text-[10px] text-mist-400">
              ({q.points} pt{q.points !== 1 ? 's' : ''})
            </span>
          </p>

          {q.type === 'mcq' && q.options && (
            <div className="space-y-2">
              {q.options.map((opt) => (
                <label
                  key={opt}
                  className="flex cursor-pointer items-center gap-2 rounded-md border border-ink-600 px-3 py-2 text-sm text-mist-200 transition hover:border-brew-500/50"
                >
                  <input
                    type="radio"
                    name={`q-${q.id}`}
                    value={opt}
                    checked={answers[q.id] === opt}
                    onChange={() => setMcqAnswer(q.id, opt)}
                    className="accent-brew-500"
                  />
                  {opt}
                </label>
              ))}
            </div>
          )}

          {q.type === 'enumeration' && (
            <textarea
              className="w-full rounded-md border border-ink-600 bg-ink-900 px-3 py-2 text-sm text-mist-100 outline-none focus:border-brew-500"
              rows={2}
              placeholder="Type each answer separated by a comma or new line"
              onChange={(e) => setEnumAnswer(q.id, e.target.value)}
            />
          )}
        </div>
      ))}

      {error && <p className="text-sm text-fail-400">{error}</p>}

      {!result ? (
        <button
          onClick={handleSubmit}
          disabled={submitting}
          className="flex items-center gap-2 rounded-md bg-brew-500 px-4 py-2 text-sm font-semibold text-ink-950 transition hover:bg-brew-400 disabled:opacity-60"
        >
          {submitting && <Loader2 size={14} className="animate-spin" />}
          Submit Knowledge Test
        </button>
      ) : (
        <div
          className={`rounded-lg border p-4 ${
            result.passed ? 'border-compile-500/40 bg-compile-500/10' : 'border-fail-500/40 bg-fail-500/10'
          }`}
        >
          <div className="flex items-center gap-2">
            {result.passed ? (
              <CheckCircle2 size={18} className="text-compile-400" />
            ) : (
              <XCircle size={18} className="text-fail-400" />
            )}
            <p className={`font-semibold ${result.passed ? 'text-compile-400' : 'text-fail-400'}`}>
              {Math.round(result.score * 100)}% — {result.passed ? 'Passed' : `Below the ${Math.round(threshold * 100)}% threshold`}
            </p>
          </div>
          <p className="mt-1 text-xs text-mist-300">
            {result.earnedPoints} / {result.possiblePoints} points.{' '}
            {!result.passed && 'You can retake this test any time.'}
          </p>
        </div>
      )}
    </div>
  );
}
