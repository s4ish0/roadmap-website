export type LessonStatus = 'locked' | 'unlocked' | 'in_progress' | 'completed';

export interface RoadmapLesson {
  id: number;
  order: number;
  slug: string;
  title: string;
  summary: string;
  bloomLevels: string[];
  status: LessonStatus;
  knowledgeScore: number | null;
  practicalScore: number | null;
  knowledgePassed: boolean;
  practicalPassed: boolean;
}

export interface RoadmapResponse {
  lessons: RoadmapLesson[];
  overallProgress: number;
}

export interface KnowledgeQuestion {
  id: number;
  type: 'mcq' | 'enumeration';
  bloomLevel: string;
  prompt: string;
  options: string[] | null;
  points: number;
}

export interface VisibleTestCase {
  id: number;
  stdin: string;
  expected_stdout: string;
}

export interface CodingChallenge {
  id: number;
  bloomLevel: string;
  title: string;
  promptMarkdown: string;
  starterCode: string;
  entryClass: string;
  visibleTestCases: VisibleTestCase[];
  hiddenTestCaseCount: number;
}

export interface LessonDetail {
  id: number;
  slug: string;
  title: string;
  summary: string;
  status: LessonStatus;
  theoryMarkdown?: string;
  bloomLevels?: string[];
  passThreshold?: number;
  progress?: {
    knowledgeScore: number | null;
    practicalScore: number | null;
    knowledgePassed: boolean;
    practicalPassed: boolean;
  };
  knowledgeQuestions?: KnowledgeQuestion[];
  codingChallenge?: CodingChallenge | null;
}

export interface RunResult {
  compileError: boolean;
  compileStderr: string;
  results: Array<{
    testCaseId: number;
    passed: boolean;
    stdout: string;
    stderr: string;
    timedOut: boolean;
  }>;
  passedCount: number;
  totalCount: number;
}

export interface SubmitResult extends RunResult {
  score: number;
  passed: boolean;
  threshold: number;
  lessonCompleted: boolean;
  unlockedNextLesson: { id: number; slug: string; title: string } | null;
}

export interface KnowledgeSubmitResult {
  score: number;
  earnedPoints: number;
  possiblePoints: number;
  passed: boolean;
  threshold: number;
  breakdown: Array<{ questionId: number; earned: number; possible: number }>;
  lessonCompleted: boolean;
  unlockedNextLesson: { id: number; slug: string; title: string } | null;
}

export interface AuthUser {
  id: number;
  username: string;
  displayName: string;
}
