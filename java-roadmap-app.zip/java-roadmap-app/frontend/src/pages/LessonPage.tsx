import React, { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Loader2, ClipboardCheck, PlayCircle, ArrowRight, Lock } from 'lucide-react';
import clsx from 'clsx';
import TopNav from '../components/layout/TopNav';
import Sidebar from '../components/layout/Sidebar';
import TheoryReader from '../components/lesson/TheoryReader';
import CodeEditor from '../components/sandbox/CodeEditor';
import OutputPanel from '../components/sandbox/OutputPanel';
import TestResultsDrawer from '../components/sandbox/TestResultsDrawer';
import AssessmentModal from '../components/assessment/AssessmentModal';
import { api } from '../api/client';
import type { LessonDetail, RoadmapLesson, RunResult } from '../types';

type Tab = 'theory' | 'sandbox';

export default function LessonPage() {
  const { lessonId } = useParams();
  const id = Number(lessonId);
  const navigate = useNavigate();

  const [lesson, setLesson] = useState<LessonDetail | null>(null);
  const [roadmap, setRoadmap] = useState<RoadmapLesson[]>([]);
  const [overallProgress, setOverallProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [tab, setTab] = useState<Tab>('theory');
  const [code, setCode] = useState('');
  const [running, setRunning] = useState(false);
  const [runResult, setRunResult] = useState<RunResult | null>(null);
  const [assessmentOpen, setAssessmentOpen] = useState<false | 'knowledge' | 'practical'>(false);
  const [unlockBanner, setUnlockBanner] = useState<string | null>(null);

  const load = useCallback(async () => {
    setError(null);
    try {
      const [lessonData, roadmapData] = await Promise.all([api.getLesson(id), api.getRoadmap()]);
      setLesson(lessonData);
      setRoadmap(roadmapData.lessons);
      setOverallProgress(roadmapData.overallProgress);
      if (lessonData.codingChallenge) setCode(lessonData.codingChallenge.starterCode);
    } catch (e: any) {
      setError(e.message);
    }
  }, [id]);

  useEffect(() => {
    load();
    setTab('theory');
    setRunResult(null);
    setUnlockBanner(null);
  }, [id, load]);

  const handleRun = async () => {
    setRunning(true);
    try {
      const res = await api.runPractical(id, code);
      setRunResult(res);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setRunning(false);
    }
  };

  const handleGraded = (unlockedNextLesson: { id: number; title: string } | null) => {
    load();
    if (unlockedNextLesson) {
      setUnlockBanner(`Nice work — "${unlockedNextLesson.title}" is now unlocked.`);
    }
  };

  if (error) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-ink-950 px-4">
        <p className="text-sm text-fail-400">{error}</p>
      </div>
    );
  }

  if (!lesson) {
    return (
      <div className="flex min-h-screen items-center justify-center gap-2 bg-ink-950 text-mist-400">
        <Loader2 className="animate-spin" size={18} />
        <span className="font-mono text-sm">Loading lesson…</span>
      </div>
    );
  }

  if (lesson.status === 'locked') {
    return (
      <div className="min-h-screen bg-ink-950">
        <TopNav overallProgress={overallProgress} />
        <div className="mx-auto flex max-w-md flex-col items-center px-4 py-24 text-center">
          <Lock size={28} className="mb-3 text-mist-400" />
          <h1 className="text-lg font-semibold text-mist-100">{lesson.title} is locked</h1>
          <p className="mt-2 text-sm text-mist-300">
            Pass the previous lesson's Knowledge and Practical tests with 80% or higher to unlock this one.
          </p>
          <button
            onClick={() => navigate('/')}
            className="mt-5 rounded-md bg-brew-500 px-4 py-2 text-sm font-semibold text-ink-950 hover:bg-brew-400"
          >
            Back to roadmap
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-ink-950">
      <TopNav overallProgress={overallProgress} />

      <div className="mx-auto flex max-w-7xl">
        <Sidebar lessons={roadmap} activeLessonId={id} />

        <main className="min-w-0 flex-1 px-4 py-8 sm:px-8">
          {unlockBanner && (
            <div className="mb-5 flex items-center gap-2 rounded-lg border border-compile-500/40 bg-compile-500/10 px-4 py-3 text-sm text-compile-400">
              <ArrowRight size={16} />
              {unlockBanner}
            </div>
          )}

          {/* Tabs */}
          <div className="mb-6 flex gap-1 border-b border-ink-600">
            {(['theory', 'sandbox'] as Tab[]).map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={clsx(
                  'border-b-2 px-4 py-2.5 font-mono text-xs uppercase tracking-wide transition',
                  tab === t ? 'border-brew-500 text-brew-400' : 'border-transparent text-mist-400 hover:text-mist-200'
                )}
              >
                {t === 'theory' ? 'Theory' : 'Code Sandbox'}
              </button>
            ))}
          </div>

          {tab === 'theory' && lesson.theoryMarkdown && (
            <TheoryReader
              title={lesson.title}
              summary={lesson.summary}
              bloomLevels={lesson.bloomLevels || []}
              markdown={lesson.theoryMarkdown}
            />
          )}

          {tab === 'sandbox' && lesson.codingChallenge && (
            <div className="space-y-4">
              <div className="rounded-lg border border-ink-600 bg-ink-800 p-4">
                <p className="mb-1 font-mono text-xs text-brew-400">{lesson.codingChallenge.title}</p>
                <pre className="whitespace-pre-wrap font-sans text-sm text-mist-200">
                  {lesson.codingChallenge.promptMarkdown}
                </pre>
              </div>

              <CodeEditor value={code} onChange={setCode} />

              <div className="flex flex-wrap gap-3">
                <button
                  onClick={handleRun}
                  disabled={running}
                  className="flex items-center gap-2 rounded-md border border-ink-600 bg-ink-800 px-4 py-2 text-sm font-semibold text-mist-100 transition hover:border-brew-500/50 disabled:opacity-60"
                >
                  {running ? <Loader2 size={14} className="animate-spin" /> : <PlayCircle size={14} />}
                  Run (visible tests)
                </button>
                <button
                  onClick={() => setAssessmentOpen('practical')}
                  className="flex items-center gap-2 rounded-md bg-brew-500 px-4 py-2 text-sm font-semibold text-ink-950 transition hover:bg-brew-400"
                >
                  <ClipboardCheck size={14} />
                  Submit for grading
                </button>
              </div>

              {runResult && (
                <>
                  <OutputPanel
                    stdout={runResult.results.map((r) => r.stdout).join('\n')}
                    stderr={runResult.compileError ? runResult.compileStderr : runResult.results.map((r) => r.stderr).join('\n')}
                    compileError={runResult.compileError}
                  />
                  {!runResult.compileError && <TestResultsDrawer results={runResult.results} />}
                </>
              )}
            </div>
          )}

          {/* Assessment entry point */}
          <div className="mt-10 rounded-xl border border-ink-600 bg-ink-800 p-5">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <p className="font-mono text-xs uppercase tracking-wide text-mist-400">Ready to advance?</p>
                <p className="mt-1 text-sm text-mist-200">
                  Pass both the Knowledge Test and the Practical Test with 80% or higher to unlock the next lesson.
                </p>
                <div className="mt-2 flex gap-4 font-mono text-xs text-mist-400">
                  <span>
                    Knowledge:{' '}
                    <span className={lesson.progress?.knowledgePassed ? 'text-compile-400' : 'text-mist-300'}>
                      {lesson.progress?.knowledgeScore != null ? `${Math.round(lesson.progress.knowledgeScore * 100)}%` : 'Not attempted'}
                    </span>
                  </span>
                  <span>
                    Practical:{' '}
                    <span className={lesson.progress?.practicalPassed ? 'text-compile-400' : 'text-mist-300'}>
                      {lesson.progress?.practicalScore != null ? `${Math.round(lesson.progress.practicalScore * 100)}%` : 'Not attempted'}
                    </span>
                  </span>
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => setAssessmentOpen('knowledge')}
                  className="rounded-md border border-ink-600 px-4 py-2 text-sm font-semibold text-mist-100 hover:border-brew-500/50"
                >
                  Take Knowledge Test
                </button>
                <button
                  onClick={() => setAssessmentOpen('practical')}
                  className="rounded-md bg-brew-500 px-4 py-2 text-sm font-semibold text-ink-950 hover:bg-brew-400"
                >
                  Take Practical Test
                </button>
              </div>
            </div>
          </div>
        </main>
      </div>

      {assessmentOpen && lesson.knowledgeQuestions && lesson.codingChallenge && (
        <AssessmentModal
          lessonId={id}
          knowledgeQuestions={lesson.knowledgeQuestions}
          codingChallenge={lesson.codingChallenge}
          threshold={lesson.passThreshold || 0.8}
          initialTab={assessmentOpen}
          onClose={() => setAssessmentOpen(false)}
          onKnowledgeGraded={(res) => handleGraded(res.unlockedNextLesson)}
          onPracticalGraded={(res) => handleGraded(res.unlockedNextLesson)}
        />
      )}
    </div>
  );
}
