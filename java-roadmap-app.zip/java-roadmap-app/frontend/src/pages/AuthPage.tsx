import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Terminal, Loader2 } from 'lucide-react';
import { useAuth } from '../state/AuthContext';

export default function AuthPage() {
  const { login, register, loading } = useAuth();
  const navigate = useNavigate();
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [form, setForm] = useState({ username: '', email: '', password: '', displayName: '' });
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      if (mode === 'login') {
        await login(form.username, form.password);
      } else {
        await register(form.username, form.email, form.password, form.displayName);
      }
      navigate('/');
    } catch (err: any) {
      setError(err.message || 'Something went wrong.');
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-ink-950 px-4">
      <div className="w-full max-w-sm rounded-xl border border-ink-600 bg-ink-800 p-8 shadow-node">
        <div className="mb-6 flex items-center gap-2">
          <span className="flex h-9 w-9 items-center justify-center rounded-md bg-brew-500/15 text-brew-400">
            <Terminal size={19} />
          </span>
          <span className="font-mono text-base font-semibold text-mist-100">
            java<span className="text-brew-400">.roadmap</span>
          </span>
        </div>

        <h1 className="mb-1 text-lg font-bold text-mist-100">
          {mode === 'login' ? 'Welcome back' : 'Create your account'}
        </h1>
        <p className="mb-6 text-sm text-mist-300">
          {mode === 'login' ? 'Log in to continue your roadmap.' : "Start Ma'am Jovi's Java curriculum."}
        </p>

        <form onSubmit={handleSubmit} className="space-y-3">
          <input
            className="w-full rounded-md border border-ink-600 bg-ink-900 px-3 py-2 text-sm text-mist-100 outline-none focus:border-brew-500"
            placeholder="Username"
            value={form.username}
            onChange={(e) => setForm({ ...form, username: e.target.value })}
            required
          />
          {mode === 'register' && (
            <>
              <input
                className="w-full rounded-md border border-ink-600 bg-ink-900 px-3 py-2 text-sm text-mist-100 outline-none focus:border-brew-500"
                placeholder="Email"
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                required
              />
              <input
                className="w-full rounded-md border border-ink-600 bg-ink-900 px-3 py-2 text-sm text-mist-100 outline-none focus:border-brew-500"
                placeholder="Display name (optional)"
                value={form.displayName}
                onChange={(e) => setForm({ ...form, displayName: e.target.value })}
              />
            </>
          )}
          <input
            className="w-full rounded-md border border-ink-600 bg-ink-900 px-3 py-2 text-sm text-mist-100 outline-none focus:border-brew-500"
            placeholder="Password"
            type="password"
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
            required
          />

          {error && <p className="text-xs text-fail-400">{error}</p>}

          <button
            type="submit"
            disabled={loading}
            className="flex w-full items-center justify-center gap-2 rounded-md bg-brew-500 py-2 text-sm font-semibold text-ink-950 transition hover:bg-brew-400 disabled:opacity-60"
          >
            {loading && <Loader2 size={14} className="animate-spin" />}
            {mode === 'login' ? 'Log in' : 'Register'}
          </button>
        </form>

        <button
          onClick={() => setMode(mode === 'login' ? 'register' : 'login')}
          className="mt-4 w-full text-center font-mono text-xs text-mist-400 hover:text-brew-400"
        >
          {mode === 'login' ? "Don't have an account? Register" : 'Already have an account? Log in'}
        </button>
      </div>
    </div>
  );
}
