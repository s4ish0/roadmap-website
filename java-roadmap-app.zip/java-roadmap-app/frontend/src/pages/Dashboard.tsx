import React, { useEffect, useState } from 'react';
import { ArrowDown, Loader2 } from 'lucide-react';
import TopNav from '../components/layout/TopNav';
import RoadmapNode from '../components/roadmap/RoadmapNode';
import { api } from '../api/client';
import type { RoadmapResponse } from '../types';

export default function Dashboard() {
  const [data, setData] = useState<RoadmapResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api
      .getRoadmap()
      .then(setData)
      .catch((e) => setError(e.message));
  }, []);

  return (
    <div className="min-h-screen bg-ink-950">
      <TopNav overallProgress={data?.overallProgress} />

      <main className="mx-auto max-w-2xl px-4 py-10 sm:px-6">
        <div className="mb-8">
          <p className="font-mono text-xs uppercase tracking-widest text-brew-400">Roadmap</p>
          <h1 className="mt-1 text-2xl font-bold text-mist-100">Java Programming Roadmap</h1>
          <p className="mt-1 text-sm text-mist-300">
            Complete each lesson's Knowledge Test and Practical Test with a score of 80% or higher to
            unlock the next one.
          </p>
        </div>

        {error && (
          <div className="mb-6 rounded-lg border border-fail-600/40 bg-fail-500/10 px-4 py-3 text-sm text-fail-400">
            {error}
          </div>
        )}

        {!data && !error && (
          <div className="flex items-center gap-2 py-16 text-mist-400">
            <Loader2 className="animate-spin" size={18} />
            <span className="font-mono text-sm">Loading roadmap…</span>
          </div>
        )}

        {data && (
          <ol className="relative">
            {data.lessons.map((lesson, idx) => (
              <li key={lesson.id} className="relative">
                <RoadmapNode lesson={lesson} />
                {idx < data.lessons.length - 1 && (
                  <div className="flex justify-center py-2">
                    <ArrowDown
                      size={18}
                      className={lesson.status === 'completed' ? 'text-compile-500' : 'text-ink-600'}
                    />
                  </div>
                )}
              </li>
            ))}
          </ol>
        )}
      </main>
    </div>
  );
}
